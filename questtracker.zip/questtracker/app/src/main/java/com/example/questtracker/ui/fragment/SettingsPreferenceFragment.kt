package com.example.questtracker.ui.fragment

import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.Fragment
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.example.questtracker.R
import com.example.questtracker.databinding.FragmentSettingsBinding
import com.example.questtracker.util.NotificationManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class SettingsPreferenceFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        if (savedInstanceState == null) {
            childFragmentManager
                .beginTransaction()
                .replace(R.id.settings_container, SettingsPreferenceFragment())
                .commit()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    class SettingsPreferenceFragment : PreferenceFragmentCompat(),
        SharedPreferences.OnSharedPreferenceChangeListener {

        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.preferences, rootKey)

            // Register shared preference change listener
            preferenceManager.sharedPreferences?.registerOnSharedPreferenceChangeListener(this)

            // Set summary providers
            findPreference<ListPreference>("theme_mode")?.summaryProvider =
                Preference.SummaryProvider<ListPreference> { preference ->
                    preference.entry
                }

            findPreference<ListPreference>("default_expansion")?.summaryProvider =
                Preference.SummaryProvider<ListPreference> { preference ->
                    preference.entry
                }

            // Set clear data preference click listener
            findPreference<Preference>("clear_local_data")?.setOnPreferenceClickListener {
                showClearDataConfirmation()
                true
            }

            // Set about preference click listener
            findPreference<Preference>("about")?.setOnPreferenceClickListener {
                showAboutDialog()
                true
            }
        }

        override fun onSharedPreferenceChanged(
            sharedPreferences: SharedPreferences?,
            key: String?
        ) {
            when (key) {
                "theme_mode" -> {
                    val themeValue =
                        sharedPreferences?.getString("theme_mode", "system") ?: "system"
                    setThemeMode(themeValue)
                }

                "auto_sync" -> {
                    val autoSync = sharedPreferences?.getBoolean("auto_sync", true) ?: true
                    // Handle auto sync setting change
                }

                "notifications_enabled" -> {
                    val notificationsEnabled =
                        sharedPreferences?.getBoolean("notifications_enabled", true) ?: true
                    // Handle notifications setting change
                }

                "default_expansion" -> {
                    // Handle default expansion change
                }
            }
        }

        private fun setThemeMode(themeValue: String) {
            val nightMode = when (themeValue) {
                "light" -> AppCompatDelegate.MODE_NIGHT_NO
                "dark" -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
            AppCompatDelegate.setDefaultNightMode(nightMode)
        }

        private fun showClearDataConfirmation() {
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("Clear Local Data")
                .setMessage("Are you sure you want to clear all locally stored quest and event data? This action cannot be undone.")
                .setPositiveButton("Clear Data") { _, _ ->
                    // Handle data clearing
                    Toast.makeText(requireContext(), "Data cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        private fun showAboutDialog() {
            androidx.appcompat.app.AlertDialog.Builder(requireContext())
                .setTitle("About FFXIV Quest Tracker")
                .setMessage(
                    "FFXIV Quest Tracker v1.0\n\n" +
                            "Track your FFXIV quests and seasonal events.\n\n" +
                            "This app is not affiliated with Square Enix or Final Fantasy XIV."
                )
                .setPositiveButton("OK", null)
                .show()
        }

        @Inject
        lateinit var notificationManager: NotificationManager

        private fun setupPreferences() {
            findPreference<Preference>("clear_notifications")?.setOnPreferenceClickListener {
                notificationManager.cancelAllNotifications()
                Toast.makeText(requireContext(), "All notifications cleared", Toast.LENGTH_SHORT)
                    .show()
                true
            }
        }

            override fun onDestroy() {
                super.onDestroy()
                preferenceManager.sharedPreferences?.unregisterOnSharedPreferenceChangeListener(this)
            }
        }
}