package com.example.questtracker.ui.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.questtracker.data.model.Quest
import com.example.questtracker.databinding.FragmentDashboardBinding
import com.example.questtracker.ui.viewmodel.QuestViewModel
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.io.BufferedReader
import java.io.InputStreamReader

@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private val questViewModel: QuestViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        binding.progressBar.visibility = View.VISIBLE

        binding.dashboardWebView.apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    return false
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    binding.progressBar.visibility = View.GONE

                    // Inject quest data after the page has loaded
                    injectQuestData()
                }
            }

            // Load the dashboard HTML
            loadDataWithBaseURL(
                "file:///android_asset/",
                getDashboardHtml(),
                "text/html",
                "UTF-8",
                null
            )
        }
    }

    private fun getDashboardHtml(): String {
        // Load the HTML template from assets
        val inputStream = requireContext().assets.open("dashboard.html")
        val reader = BufferedReader(InputStreamReader(inputStream))
        val stringBuilder = StringBuilder()
        var line: String?

        while (reader.readLine().also { line = it } != null) {
            stringBuilder.append(line).append("\n")
        }

        reader.close()
        inputStream.close()

        return stringBuilder.toString()
    }

    private fun injectQuestData() {
        // This will fetch the quest data and inject it into the WebView
        val quests = runBlocking { questViewModel.filteredQuests.first() }
        val questsJson = Gson().toJson(quests)

        // Inject the data into the WebView
        val jsCode = "window.questData = $questsJson;"
        binding.dashboardWebView.evaluateJavascript(jsCode, null)

        // Call the React function to process the data
        binding.dashboardWebView.evaluateJavascript(
            "window.updateQuestData(window.questData);",
            null
        )
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}