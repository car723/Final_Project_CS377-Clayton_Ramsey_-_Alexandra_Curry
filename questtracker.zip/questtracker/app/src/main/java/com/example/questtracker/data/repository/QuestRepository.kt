package com.example.questtracker.data.repository

import com.example.questtracker.data.local.QuestDao
import com.example.questtracker.data.model.Quest
import com.example.questtracker.data.remote.FFXIVApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

class QuestRepository @Inject constructor(
    private val questDao: QuestDao,
    private val ffxivApi: FFXIVApi
) {
    // Local database operations
    fun getAllQuests(): Flow<List<Quest>> = questDao.getAllQuests()

    fun getSeasonalQuests(): Flow<List<Quest>> = questDao.getSeasonalQuests()

    fun getActiveQuests(): Flow<List<Quest>> = questDao.getActiveQuests()

    fun getQuestsBySeasonalEvent(eventName: String): Flow<List<Quest>> {
        return questDao.getQuestsBySeasonalEvent(eventName)
    }

    fun getRecentlyTrackedQuests(): Flow<List<Quest>> {
        return flow {
            val quests = questDao.getAllQuests().first()
                .sortedByDescending { it.lastActiveTimestamp ?: 0 }
                .take(10)  // Get the 10 most recently tracked quests
            emit(quests)
        }
    }

    suspend fun getQuestById(questId: Long): Quest? = questDao.getQuestById(questId)

    suspend fun insertQuest(quest: Quest): Long = questDao.insertQuest(quest)

    suspend fun updateQuest(quest: Quest) = questDao.updateQuest(quest)

    suspend fun deleteQuest(quest: Quest) = questDao.deleteQuest(quest)

    suspend fun updateQuestTime(questId: Long, additionalSeconds: Long) {
        questDao.updateQuestTime(questId, additionalSeconds)
    }

    suspend fun updateLastActiveTimestamp(questId: Long, timestamp: Long) {
        questDao.updateLastActiveTimestamp(questId, timestamp)
    }

    // Remote API operations
    suspend fun fetchAndSaveQuests() {
        try {
            val remoteQuests = ffxivApi.getAllQuests()
            questDao.insertQuests(remoteQuests)
        } catch (_: Exception) {
            // Handle error
        }
    }

    suspend fun trackQuestTimeOnServer(questId: String, timeInSeconds: Long) {
        try {
            ffxivApi.trackQuestTime(questId, timeInSeconds)
        } catch (_: Exception) {
            // Handle error
        }
    }
}