package com.example.questtracker.ui.adapter

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.questtracker.R
import com.example.questtracker.data.model.SeasonalEvent
import com.example.questtracker.databinding.ItemSeasonalEventBinding
import com.example.questtracker.util.DateUtils

class SeasonalEventAdapter(
    private val onEventClicked: (SeasonalEvent) -> Unit,
    private val onAddToCalendarClicked: (SeasonalEvent) -> Unit
) : ListAdapter<SeasonalEvent, SeasonalEventAdapter.EventViewHolder>(EventDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventViewHolder {
        val binding = ItemSeasonalEventBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EventViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EventViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class EventViewHolder(
        private val binding: ItemSeasonalEventBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.cardEvent.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onEventClicked(getItem(position))
                }
            }

            binding.btnAddToCalendar.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onAddToCalendarClicked(getItem(position))
                }
            }
        }

        @SuppressLint("SetTextI18n")
        fun bind(event: SeasonalEvent) {
            val context = binding.root.context
            binding.apply {
                // Set event title and dates
                eventTitle.text = event.name
                eventDates.text =
                    "${DateUtils.formatDate(event.startDate)} - ${DateUtils.formatDate(event.endDate)}"
                eventDescription.text = event.description

                // Set event location and level
                eventLocation.text = event.questStartLocation ?: "Various Locations"
                eventMinLevel.text = "Level: ${event.minimumLevel}+"

                // Set event rewards if available
                if (!event.rewards.isNullOrBlank()) {
                    eventRewards.text = event.rewards
                    rewardsSection.alpha = 1.0f
                } else {
                    eventRewards.text = "Details unavailable"
                    rewardsSection.alpha = 1.0f
                }

                // Calculate event status
                val eventStatus = DateUtils.getEventStatus(event.startDate, event.endDate)

                // Update status badge and timing info
                when (eventStatus) {
                    is DateUtils.EventStatus.ACTIVE -> {
                        statusBadge.backgroundTintList = ColorStateList.valueOf(
                            ContextCompat.getColor(context, R.color.event_active)
                        )
                        statusText.text = "ACTIVE"
                        timeInfo.text = eventStatus.message
                        btnAddToCalendar.isEnabled = false
                        btnAddToCalendar.alpha = 0.5f
                    }

                    is DateUtils.EventStatus.UPCOMING -> {
                        statusBadge.backgroundTintList = ColorStateList.valueOf(
                            ContextCompat.getColor(context, R.color.event_upcoming)
                        )
                        statusText.text = "UPCOMING"
                        timeInfo.text = eventStatus.message
                        btnAddToCalendar.isEnabled = true
                        btnAddToCalendar.alpha = 1.0f
                    }

                    is DateUtils.EventStatus.ENDED -> {
                        statusBadge.backgroundTintList = ColorStateList.valueOf(
                            ContextCompat.getColor(context, R.color.event_ended)
                        )
                        statusText.text = "ENDED"
                        timeInfo.text = eventStatus.message
                        btnAddToCalendar.isEnabled = false
                        btnAddToCalendar.alpha = 0.5f
                    }
                }

                // Set event image based on name
                val imageResId = when {
                    event.name.contains("Starlight") -> R.drawable.img_starlight
                    event.name.contains("All Saints") -> R.drawable.img_halloween
                    event.name.contains("Moonfire") -> R.drawable.img_summer
                    event.name.contains("Heavensturn") -> R.drawable.img_new_year
                    event.name.contains("Little Ladies") -> R.drawable.img_little_ladies
                    event.name.contains("Valentione") -> R.drawable.img_valentione
                    event.name.contains("Make It Rain") -> R.drawable.img_gold_saucer
                    event.name.contains("Rising") -> R.drawable.img_rising
                    event.name.contains("Hatching") -> R.drawable.img_hatching
                    else -> R.drawable.img_default_event
                }
                eventImage.setImageResource(imageResId)
            }
        }
    }

    private class EventDiffCallback : DiffUtil.ItemCallback<SeasonalEvent>() {
        override fun areItemsTheSame(oldItem: SeasonalEvent, newItem: SeasonalEvent): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: SeasonalEvent, newItem: SeasonalEvent): Boolean {
            return oldItem == newItem
        }
    }
}