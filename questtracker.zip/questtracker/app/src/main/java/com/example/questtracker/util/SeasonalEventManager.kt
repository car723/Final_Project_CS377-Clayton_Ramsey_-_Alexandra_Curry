package com.example.questtracker.util

import android.util.Log
import com.example.questtracker.data.model.SeasonalEvent
import com.example.questtracker.data.repository.SeasonalEventRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SeasonalEventManager @Inject constructor(
    private val seasonalEventRepository: SeasonalEventRepository
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _notificationEventFlow = MutableStateFlow<SeasonalEvent?>(null)
    val notificationEventFlow: StateFlow<SeasonalEvent?> = _notificationEventFlow

    private val _upcomingEventFlow = MutableStateFlow<List<SeasonalEvent>>(emptyList())
    val upcomingEventFlow: StateFlow<List<SeasonalEvent>> = _upcomingEventFlow

    fun initialize() {
        scope.launch {
            try {
            refreshEvents()
            } catch (e: Exception) {
            Log.e("SeasonalEventManager", "Error initializing: ${e.message}", e)

                _upcomingEventFlow.value = emptyList()
                _notificationEventFlow.value = null
            }
        }
    }

    suspend fun refreshEvents() {
        // Update active status of all events
        seasonalEventRepository.updateActiveStatus()

        // Get upcoming events but only set them once
        val upcomingEventsList = seasonalEventRepository.getUpcomingEvents().first()
        if (_upcomingEventFlow.value != upcomingEventsList) {
            _upcomingEventFlow.value = upcomingEventsList
        }

        // Check for new active events
        val activeEvents = seasonalEventRepository.getActiveEvents().first()
        if (activeEvents.isNotEmpty()) {
            // Notify about the most recent event that has become active
            val latestEvent = activeEvents.maxByOrNull { it.startDate }
            if (latestEvent != null && latestEvent != _notificationEventFlow.value) {
                _notificationEventFlow.value = latestEvent
            }
        }
    }

    fun exportToCalendar(): List<SeasonalEvent> {
        // In a real implementation, this would add all events to the calendar
        // For now, just return the list of upcoming events
        return _upcomingEventFlow.value
    }
}