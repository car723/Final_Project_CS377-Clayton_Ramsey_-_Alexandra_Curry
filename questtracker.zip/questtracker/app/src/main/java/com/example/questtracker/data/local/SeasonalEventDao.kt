package com.example.questtracker.data.local

import androidx.room.*
import com.example.questtracker.data.model.SeasonalEvent
import kotlinx.coroutines.flow.Flow
import java.util.Date

@Dao
interface SeasonalEventDao {
    @Query("SELECT * FROM seasonal_events ORDER BY startDate DESC")
    fun getAllEvents(): Flow<List<SeasonalEvent>>

    @Query("SELECT * FROM seasonal_events WHERE isActive = 1 ORDER BY startDate DESC")
    fun getActiveEvents(): Flow<List<SeasonalEvent>>

    @Query("SELECT * FROM seasonal_events WHERE startDate >= :date ORDER BY startDate ASC")
    fun getUpcomingEvents(date: Date): Flow<List<SeasonalEvent>>

    @Query("SELECT * FROM seasonal_events WHERE name = :name")
    suspend fun getEventByName(name: String): SeasonalEvent?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: SeasonalEvent): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<SeasonalEvent>)

    @Update
    suspend fun updateEvent(event: SeasonalEvent)

    @Delete
    suspend fun deleteEvent(event: SeasonalEvent)

    @Query("UPDATE seasonal_events SET isActive = (startDate <= :currentDate AND endDate >= :currentDate)")
    suspend fun updateActiveStatus(currentDate: Date)
}