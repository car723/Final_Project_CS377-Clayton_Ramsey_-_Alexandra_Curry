package com.example.questtracker

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class QuestTrackerApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize any application-wide components here if needed
    }
}