package com.example.questtracker.util

import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object DateUtils {
    private val DATE_FORMAT = SimpleDateFormat("MMMM dd, yyyy", Locale.US)
    private val TIME_FORMAT = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val DATE_TIME_FORMAT = SimpleDateFormat("MMMM dd, yyyy HH:mm", Locale.US)
    private val SHORT_DATE_FORMAT = SimpleDateFormat("MMM dd", Locale.US)

    // Format a date to the standard format
    fun formatDate(date: Date?): String {
        return date?.let { DATE_FORMAT.format(it) } ?: ""
    }

    // Format a date to a short format (e.g., "Jan 01")
    fun formatShortDate(date: Date?): String {
        return date?.let { SHORT_DATE_FORMAT.format(it) } ?: ""
    }

    // Format time spent in seconds to a readable format
    fun formatTimeSpent(seconds: Long): String {
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return String.format("%02d:%02d:%02d", hours, minutes, secs)
    }

    // Get days between two dates
    fun daysBetween(start: Date, end: Date): Long {
        // Normalize to start of day to avoid time discrepancies
        val startDay = normalizeToStartOfDay(start)
        val endDay = normalizeToStartOfDay(end)

        // Calculate difference in days
        return TimeUnit.MILLISECONDS.toDays(endDay.time - startDay.time)
    }

    // Get event status based on current date
    fun getEventStatus(startDate: Date, endDate: Date): EventStatus {
        val currentDate = Date()
        val normalizedCurrent = normalizeToStartOfDay(currentDate)
        val normalizedStart = normalizeToStartOfDay(startDate)
        val normalizedEnd = normalizeToStartOfDay(endDate)

        return when {
            normalizedCurrent.before(normalizedStart) ->
                EventStatus.UPCOMING("Starts in ${daysUntil(startDate)} days")

            normalizedCurrent.after(normalizedEnd) ->
                EventStatus.ENDED("Ended ${daysAgo(endDate)} days ago")

            else ->
                EventStatus.ACTIVE("Ends in ${daysUntil(endDate)} days")
        }
    }

    // Get days until a future date
    fun daysUntil(date: Date): Int {
        val currentDate = normalizeToStartOfDay(Date())
        val targetDate = normalizeToStartOfDay(date)

        if (currentDate.after(targetDate)) return 0

        val diff = targetDate.time - currentDate.time
        return (diff / (1000 * 60 * 60 * 24)).toInt()
    }

    // Get days since a past date
    fun daysAgo(date: Date): Int {
        val currentDate = normalizeToStartOfDay(Date())
        val targetDate = normalizeToStartOfDay(date)

        if (currentDate.before(targetDate)) return 0

        val diff = currentDate.time - targetDate.time
        return (diff / (1000 * 60 * 60 * 24)).toInt()
    }

    // Format relative time (e.g., "5 minutes ago", "in 2 days")
    fun getRelativeTimeSpan(date: Date): String {
        val now = Date()
        val diffInMillis = date.time - now.time
        val diffInSeconds = TimeUnit.MILLISECONDS.toSeconds(abs(diffInMillis))
        val diffInMinutes = TimeUnit.MILLISECONDS.toMinutes(abs(diffInMillis))
        val diffInHours = TimeUnit.MILLISECONDS.toHours(abs(diffInMillis))
        val diffInDays = TimeUnit.MILLISECONDS.toDays(abs(diffInMillis))

        val isFuture = diffInMillis > 0

        return when {
            diffInDays > 30 -> formatDate(date)
            diffInDays > 0 -> if (isFuture) "in $diffInDays days" else "$diffInDays days ago"
            diffInHours > 0 -> if (isFuture) "in $diffInHours hours" else "$diffInHours hours ago"
            diffInMinutes > 0 -> if (isFuture) "in $diffInMinutes minutes" else "$diffInMinutes minutes ago"
            else -> if (isFuture) "in a moment" else "just now"
        }
    }

    // Normalize a date to the start of the day (00:00:00)
    private fun normalizeToStartOfDay(date: Date): Date {
        val calendar = Calendar.getInstance().apply {
            time = date
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.time
    }

    sealed class EventStatus {
        data class UPCOMING(val message: String) : EventStatus()
        data class ACTIVE(val message: String) : EventStatus()
        data class ENDED(val message: String) : EventStatus()
    }
}