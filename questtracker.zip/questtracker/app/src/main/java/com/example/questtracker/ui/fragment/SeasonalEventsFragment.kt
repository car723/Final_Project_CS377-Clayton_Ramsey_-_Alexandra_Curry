package com.example.questtracker.ui.fragment

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.provider.CalendarContract
import android.view.*
import android.widget.Toast
import androidx.annotation.RequiresPermission
import androidx.appcompat.widget.SearchView
import androidx.compose.runtime.Composable
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.questtracker.R
import com.example.questtracker.data.model.SeasonalEvent
import com.example.questtracker.databinding.FragmentSeasonalEventsBinding
import com.example.questtracker.ui.adapter.SeasonalEventAdapter
import com.example.questtracker.ui.viewmodel.SeasonalEventViewModel
import com.example.questtracker.util.NotificationManager
import com.example.questtracker.util.SeasonalEventManager
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class SeasonalEventsFragment : Fragment() {

    private var _binding: FragmentSeasonalEventsBinding? = null
    private val binding get() = _binding!!

    private val seasonalEventViewModel: SeasonalEventViewModel by viewModels()
    private lateinit var eventAdapter: SeasonalEventAdapter

    @Inject
    lateinit var seasonalEventManager: SeasonalEventManager

    @Inject
    lateinit var notificationManager: NotificationManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSeasonalEventsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupTabLayout()
        setupEventWidget()
        setupRefreshAction()

        if (savedInstanceState == null) {
            initializeSeasonalEventManager()
        }

        observeEvents()
    }

    private fun setupRecyclerView() {
        eventAdapter = SeasonalEventAdapter(
            onEventClicked = { event ->
                navigateToEventDetail(event)
            },
            onAddToCalendarClicked = { event ->
                addEventToCalendar(event)
            }
        )

        binding.recyclerEvents.adapter = eventAdapter
    }

    private fun setupTabLayout() {
        binding.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> observeActiveEvents()
                    1 -> observeUpcomingEvents()
                    2 -> observeAllEvents()
                    else -> observeAllEvents()
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun setupEventWidget() {
        // Set up the event widget that shows upcoming event info
        binding.upcomingEventWidget.setOnClickListener {
            val activeEvents = seasonalEventViewModel.activeEvents.value
            val upcomingEvents = seasonalEventViewModel.upcomingEvents.value

            // Navigate to the nearest event (active or upcoming)
            val eventToShow = activeEvents.firstOrNull() ?: upcomingEvents.firstOrNull()
            eventToShow?.let { navigateToEventDetail(it) }
        }
    }

    private fun setupRefreshAction() {
        binding.swipeRefresh.setOnRefreshListener {
            refreshEvents()
        }
    }

    @SuppressLint("MissingPermission")
    private fun initializeSeasonalEventManager() {
        // Initialize the event manager
        seasonalEventManager.initialize()

        // Observe event notifications
        viewLifecycleOwner.lifecycleScope.launch {
            seasonalEventManager.notificationEventFlow.collectLatest { event ->
                event?.let {
                    notificationManager.showEventNotification(it)
                }
            }
        }
    }

    private fun observeEvents() {
        // Default to showing active events
        observeActiveEvents()

        // Also observe upcoming event for the widget
        viewLifecycleOwner.lifecycleScope.launch {
            val upcomingEvents = seasonalEventManager.upcomingEventFlow.first()
            updateUpcomingEventWidget(upcomingEvents.firstOrNull())

            seasonalEventManager.upcomingEventFlow
                .collectLatest { events ->
                    updateUpcomingEventWidget(events.firstOrNull())
                }
        }
    }

    private fun observeActiveEvents() {
        viewLifecycleOwner.lifecycleScope.launch {
            seasonalEventViewModel.activeEvents.collectLatest { events ->
                eventAdapter.submitList(events)
                updateEmptyView(events.isEmpty())
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun observeUpcomingEvents() {
        viewLifecycleOwner.lifecycleScope.launch {
            seasonalEventViewModel.upcomingEvents.collectLatest { events ->
                eventAdapter.submitList(events)
                updateEmptyView(events.isEmpty())
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun observeAllEvents() {
        viewLifecycleOwner.lifecycleScope.launch {
            seasonalEventViewModel.filteredEvents.collectLatest { events ->
                eventAdapter.submitList(events)
                updateEmptyView(events.isEmpty())
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    private fun updateEmptyView(isEmpty: Boolean) {
        binding.recyclerEvents.visibility = if (isEmpty) View.GONE else View.VISIBLE
        binding.emptyView.visibility = if (isEmpty) View.VISIBLE else View.GONE
    }

    @SuppressLint("SetTextI18n")
    private fun updateUpcomingEventWidget(event: SeasonalEvent?) {
        // If we have an upcoming event, update the widget
        event?.let {
            binding.upcomingEventWidget.visibility = View.VISIBLE
            binding.upcomingEventTitle.text = it.name
            binding.upcomingEventDate.text = "Starts ${seasonalEventViewModel.getDaysUntilEvent(it)} days from now"
            binding.upcomingEventLocation.text = it.questStartLocation
        } ?: run {
            // No upcoming events
            binding.upcomingEventWidget.visibility = View.GONE
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateActiveEventsWidget(event: SeasonalEvent?) {
        // If we have an active event, update the active event section
        event?.let {
            binding.activeEventBanner.visibility = View.VISIBLE
            binding.activeEventName.text = it.name
            binding.activeEventDays.text = "Ending in ${seasonalEventViewModel.getDaysRemaining(it)} days"
        } ?: run {
            // No active events
            binding.activeEventBanner.visibility = View.GONE
        }
    }

    private fun navigateToEventDetail(event: SeasonalEvent) {
        val bundle = Bundle()
        bundle.putLong("eventId", event.id)
        findNavController().navigate(R.id.eventDetailFragment, bundle)
    }

    private fun addEventToCalendar(event: SeasonalEvent) {
        val startMillis = event.startDate.time
        val endMillis = event.endDate.time

        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            .putExtra(CalendarContract.Events.TITLE, "FFXIV: ${event.name}")
            .putExtra(CalendarContract.Events.DESCRIPTION, event.description)
            .putExtra(CalendarContract.Events.EVENT_LOCATION, event.questStartLocation)
            .putExtra(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_BUSY)

        if (intent.resolveActivity(requireActivity().packageManager) != null) {
            startActivity(intent)
        } else {
            Snackbar.make(binding.root, "No calendar app available", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun refreshEvents() {
        binding.swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            seasonalEventViewModel.refreshEvents()
            seasonalEventManager.refreshEvents()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_seasonal_events, menu)

        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { seasonalEventViewModel.searchEvents(it) }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let { seasonalEventViewModel.searchEvents(it) }
                return true
            }
        })

        super.onCreateOptionsMenu(menu, inflater)
    }

    @Deprecated("Deprecated in Java")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> {
                refreshEvents()
                true
            }
            R.id.action_calendar -> {
                exportAllEventsToCalendar()
                true
            }
            R.id.action_notifications -> {
                toggleEventNotifications()
                true
            }
            R.id.action_clear_notifications -> {
                notificationManager.cancelAllNotifications()
                Toast.makeText(requireContext(), "All notifications cleared", Toast.LENGTH_SHORT).show()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun exportAllEventsToCalendar() {
        lifecycleScope.launch {
            val events = seasonalEventManager.exportToCalendar()
            Snackbar.make(
                binding.root,
                "Exported ${events.size} events to calendar",
                Snackbar.LENGTH_SHORT
            ).show()
        }
    }

    private fun toggleEventNotifications() {
        // This would toggle event notifications in a real implementation
        Snackbar.make(
            binding.root,
            "Event notifications toggled",
            Snackbar.LENGTH_SHORT
        ).show()
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    private fun showEventNotification(event: SeasonalEvent) {
        if (event.isActive) {
            notificationManager.showEventNotification(event)
            Toast.makeText(requireContext(), "Notification shown for: ${event.name}", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}