package com.example.questtracker.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.questtracker.R
import com.example.questtracker.data.model.FFXIVExpansion
import com.example.questtracker.data.model.Quest
import com.example.questtracker.data.model.QuestType
import com.example.questtracker.databinding.FragmentQuestListBinding
import com.example.questtracker.ui.adapter.QuestAdapter
import com.example.questtracker.ui.viewmodel.QuestViewModel
import com.google.android.material.chip.Chip
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class QuestListFragment : Fragment() {

    private var _binding: FragmentQuestListBinding? = null
    private val binding get() = _binding!!

    private val questViewModel: QuestViewModel by viewModels()
    private lateinit var questAdapter: QuestAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuestListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupExpansionChips()
        setupTabLayout()
        setupFab()
        observeData()
    }

    private fun setupRecyclerView() {
        questAdapter = QuestAdapter(
            onQuestClicked = { quest ->
                navigateToQuestDetail(quest)
            },
            onTrackClicked = { quest ->
                questViewModel.startTrackingQuest(quest.id)
            }
        )

        binding.recyclerQuests.apply {
            adapter = questAdapter
            layoutManager = LinearLayoutManager(requireContext())
            addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupExpansionChips() {
        val expansions = FFXIVExpansion.values().filter { it != FFXIVExpansion.UNKNOWN }

        expansions.forEach { expansion ->
            val chip = Chip(requireContext()).apply {
                text = expansion.name.replace("_", " ")
                isCheckable = true
                setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) {
                        questViewModel.filterByExpansion(expansion)
                    } else if (binding.expansionFilterChips.checkedChipId == View.NO_ID) {
                        questViewModel.filterByExpansion(null)
                    }
                }
            }
            binding.expansionFilterChips.addView(chip)
        }
    }

    private fun setupTabLayout() {
        binding.tabs.addOnTabSelectedListener(object : com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> questViewModel.filterByQuestType(null) // All quests
                    1 -> questViewModel.filterByQuestType(QuestType.MAIN_SCENARIO) // MSQ
                    2 -> questViewModel.filterBySeasonalEvent("") // Seasonal
                }
            }

            override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}

            override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab?) {}
        })
    }

    private fun setupFab() {
        binding.fabAddQuest.setOnClickListener {
            findNavController().navigate(R.id.action_questListFragment_to_addQuestFragment)
        }
    }

    private fun observeData() {
        viewLifecycleOwner.lifecycleScope.launch {
            questViewModel.filteredQuests.collectLatest { quests ->
                questAdapter.submitList(quests)

                val emptyTextView = view?.findViewById<View>(R.id.empty_view)
                if (quests.isEmpty()) {
                    binding.recyclerQuests.visibility = View.GONE
                    emptyTextView?.visibility = View.VISIBLE
                } else {
                    binding.recyclerQuests.visibility = View.VISIBLE
                    emptyTextView?.visibility = View.GONE
                }
            }
        }
    }

    private fun navigateToQuestDetail(quest: Quest) {
        val action = QuestListFragmentDirections.actionQuestListFragmentToQuestDetailFragment(quest.id)
        findNavController().navigate(action)
    }

    @Deprecated("Deprecated in Java")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_quest_list, menu)

        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                query?.let { questViewModel.searchQuests(it) }
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let { questViewModel.searchQuests(it) }
                return true
            }
        })

        super.onCreateOptionsMenu(menu, inflater)
    }

    @Deprecated("Deprecated in Java")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_refresh -> {
                questViewModel.fetchQuests()
                true
            }
            R.id.action_filter -> {
                // Show filter dialog
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}