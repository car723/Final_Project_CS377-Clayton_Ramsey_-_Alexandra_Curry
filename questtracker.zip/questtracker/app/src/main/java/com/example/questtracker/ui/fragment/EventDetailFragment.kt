package com.example.questtracker.ui.fragment

import android.annotation.SuppressLint
import android.content.Intent
import java.text.SimpleDateFormat
import java.util.Locale
import android.net.Uri
import android.os.Bundle
import android.provider.CalendarContract
import android.view.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.Navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.questtracker.R
import com.example.questtracker.data.model.SeasonalEvent
import com.example.questtracker.databinding.FragmentEventDetailBinding
import com.example.questtracker.ui.activity.MainActivity
import com.example.questtracker.ui.adapter.QuestAdapter
import com.example.questtracker.ui.viewmodel.QuestViewModel
import com.example.questtracker.ui.viewmodel.SeasonalEventViewModel
import com.example.questtracker.util.DateUtils
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*
import kotlin.jvm.java

@AndroidEntryPoint
class EventDetailFragment : Fragment() {

    private var _binding: FragmentEventDetailBinding? = null
    private val binding get() = _binding!!

    private val args: EventDetailFragmentArgs by navArgs()

    private val seasonalEventViewModel: SeasonalEventViewModel by viewModels()
    private val questViewModel: QuestViewModel by viewModels()

    private lateinit var questAdapter: QuestAdapter
    private var event: SeasonalEvent? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentEventDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupNavigation()
        loadEvent()
    }

    private fun setupRecyclerView() {
        questAdapter = QuestAdapter(
            onQuestClicked = { quest ->
                val bundle = Bundle()
                bundle.putLong("questId", quest.id)
                findNavController().navigate(R.id.questDetailFragment, bundle)
            },
            onTrackClicked = { quest ->
                questViewModel.startTrackingQuest(quest.id)
                Snackbar.make(binding.root, "Now tracking: ${quest.title}", Snackbar.LENGTH_SHORT).show()
            }
        )

        binding.recyclerEventQuests.apply {
            adapter = questAdapter
            layoutManager = LinearLayoutManager(requireContext())
            addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupNavigation() {
        binding.toolbar.setNavigationOnClickListener {
            findNavController().navigateUp()
        }
    }

    private fun loadEvent() {
        viewLifecycleOwner.lifecycleScope.launch {
            // Get event by ID
            val loadedEvent = seasonalEventViewModel.getEventById(args.eventId)
            if (loadedEvent != null) {
                event = loadedEvent
                updateUI(loadedEvent)
                observeEventQuests(loadedEvent)
            } else {
                Snackbar.make(binding.root, "Error loading event", Snackbar.LENGTH_SHORT).show()
                findNavController().navigateUp()
            }
        }
    }

    private fun updateUI(event: SeasonalEvent) {
        binding.apply {
            // Set event basic info
            toolbarLayout.title = event.name
            eventDescription.text = event.description
            eventDates.text = "${DateUtils.formatDate(event.startDate)} - ${DateUtils.formatDate(event.endDate)}"
            eventLocation.text = event.questStartLocation ?: "Various Locations"
            eventMinimumLevel.text = "Required Level: ${event.minimumLevel}"

            // Set rewards info
            if (event.rewards.isNullOrBlank()) {
                rewardsCard.visibility = View.GONE
            } else {
                rewardsCard.visibility = View.VISIBLE
                eventRewards.text = event.rewards
            }

            // Set event status
            val eventStatus = DateUtils.getEventStatus(event.startDate, event.endDate)
            updateEventStatus(eventStatus)

            // Set calendar info
            val calendar = Calendar.getInstance()
            calendar.time = event.startDate
            eventYear.text = calendar.get(Calendar.YEAR).toString()
            eventMonth.text = SimpleDateFormat("MMMM", Locale.US).format(event.startDate)
            eventDay.text = calendar.get(Calendar.DAY_OF_MONTH).toString()

            // Set event image based on name
            val imageResId = when {
                event.name.contains("Starlight") -> R.drawable.img_starlight
                event.name.contains("All Saints") -> R.drawable.img_halloween
                event.name.contains("Moonfire") -> R.drawable.img_summer
                event.name.contains("Heavensturn") -> R.drawable.img_new_year
                event.name.contains("Little Ladies") -> R.drawable.img_little_ladies
                event.name.contains("Valentione") -> R.drawable.img_valentione
                event.name.contains("Make It Rain") -> R.drawable.img_gold_saucer
                event.name.contains("Rising") -> R.drawable.img_rising
                event.name.contains("Hatching") -> R.drawable.img_hatching
                else -> R.drawable.img_default_event
            }
            eventImage.setImageResource(imageResId)

            // Setup button actions
            btnAddToCalendar.setOnClickListener {
                addEventToCalendar(event)
            }

            btnOpenGuide.setOnClickListener {
                openEventGuide(event)
            }
        }
    }

    private fun updateEventStatus(eventStatus: DateUtils.EventStatus) {
        binding.apply {
            when (eventStatus) {
                is DateUtils.EventStatus.ACTIVE -> {
                    eventStatusText.text = "ACTIVE"
                    eventStatusText.setTextColor(ContextCompat.getColor(requireContext(), R.color.event_active))
                    eventTimeRemaining.text = eventStatus.message
                    progressContainer.visibility = View.VISIBLE
                    // Show progress indicator for active event
                    val daysTotal = DateUtils.daysBetween(event?.startDate ?: Date(), event?.endDate ?: Date())
                    val daysRemaining = DateUtils.daysUntil(event?.endDate ?: Date())
                    val progress = if (daysTotal > 0) {
                        ((daysTotal - daysRemaining) / daysTotal.toFloat() * 100).toInt()
                    } else 0
                    eventProgress.progress = progress
                    progressText.text = "$progress% Complete"
                }
                is DateUtils.EventStatus.UPCOMING -> {
                    eventStatusText.text = "UPCOMING"
                    eventStatusText.setTextColor(ContextCompat.getColor(requireContext(), R.color.event_upcoming))
                    eventTimeRemaining.text = eventStatus.message
                    progressContainer.visibility = View.GONE

                    // Enable calendar button for upcoming events
                    btnAddToCalendar.isEnabled = true
                    btnAddToCalendar.alpha = 1.0f
                }
                is DateUtils.EventStatus.ENDED -> {
                    eventStatusText.text = "ENDED"
                    eventStatusText.setTextColor(ContextCompat.getColor(requireContext(), R.color.event_ended))
                    eventTimeRemaining.text = eventStatus.message
                    progressContainer.visibility = View.GONE

                    // Disable calendar button for ended events
                    btnAddToCalendar.isEnabled = false
                    btnAddToCalendar.alpha = 0.5f
                }
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun observeEventQuests(event: SeasonalEvent) {
        viewLifecycleOwner.lifecycleScope.launch {
            questViewModel.getQuestsBySeasonalEvent(event.name).collectLatest { quests ->
                questAdapter.submitList(quests)

                // Set completion percentage
                val completedQuests = quests.count { it.isCompleted }
                val totalQuests = quests.size

                if (totalQuests > 0) {
                    val completionPercentage = (completedQuests * 100) / totalQuests
                    binding.questsCompletionText.text = "$completedQuests/$totalQuests quests completed ($completionPercentage%)"
                    binding.questsProgress.progress = completionPercentage
                } else {
                    binding.questsCompletionText.text = "No quests available"
                    binding.questsProgress.progress = 0
                }

                // Show/hide empty view
                if (quests.isEmpty()) {
                    binding.recyclerEventQuests.visibility = View.GONE
                    binding.emptyQuestsView.visibility = View.VISIBLE

                    // Add button to create a quest
                    binding.btnCreateQuest.visibility = View.VISIBLE
                    binding.btnCreateQuest.setOnClickListener {
                        navigateToAddQuest(event)
                    }
                } else {
                    binding.recyclerEventQuests.visibility = View.VISIBLE
                    binding.emptyQuestsView.visibility = View.GONE
                    binding.btnCreateQuest.visibility = View.GONE
                }
            }
        }
    }

    private fun navigateToAddQuest(event: SeasonalEvent) {
        val bundle = Bundle().apply {
            putString("eventName", event.name)
            putLong("eventId", event.id)
        }
        findNavController().navigate(R.id.action_enhancedEventDetailFragment_to_addQuestFragment, bundle)
    }

    private fun addEventToCalendar(event: SeasonalEvent) {
        val startMillis = event.startDate.time
        val endMillis = event.endDate.time

        val intent = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
            .putExtra(CalendarContract.Events.TITLE, "FFXIV: ${event.name}")
            .putExtra(CalendarContract.Events.DESCRIPTION, event.description)
            .putExtra(CalendarContract.Events.EVENT_LOCATION, event.questStartLocation)
            .putExtra(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_BUSY)

        if (intent.resolveActivity(requireActivity().packageManager) != null) {
            startActivity(intent)
        } else {
            Snackbar.make(binding.root, "No calendar app available", Snackbar.LENGTH_SHORT).show()
        }
    }

    private fun openEventGuide(event: SeasonalEvent) {
        // Format event name for URL (replace spaces with dashes, lowercase)
        val formattedName = event.name.lowercase(Locale.US).replace(" ", "-")
        val url = "https://ffxiv.consolegameswiki.com/wiki/${formattedName}"

        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (intent.resolveActivity(requireActivity().packageManager) != null) {
            startActivity(intent)
        } else {
            Snackbar.make(binding.root, "No browser app available", Snackbar.LENGTH_SHORT).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_event_detail, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_share_event -> {
                shareEvent()
                true
            }
            R.id.action_set_reminder -> {
                showReminderDialog()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun shareEvent() {
        event?.let { event ->
            val shareText = """
                FFXIV Seasonal Event: ${event.name}
                ${DateUtils.formatDate(event.startDate)} - ${DateUtils.formatDate(event.endDate)}
                Location: ${event.questStartLocation}
                Required Level: ${event.minimumLevel}
                
                ${event.description}
                
                Shared from FFXIV Quest Tracker app
            """.trimIndent()

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "FFXIV Seasonal Event: ${event.name}")
                putExtra(Intent.EXTRA_TEXT, shareText)
            }

            startActivity(Intent.createChooser(intent, "Share Event"))
        }
    }

    private fun showReminderDialog() {
        event?.let { event ->
            val options = arrayOf(
                "1 day before",
                "3 days before",
                "1 week before"
            )

            MaterialAlertDialogBuilder(requireContext())
                .setTitle("Set Reminder")
                .setItems(options) { _, which ->
                    val reminderDays = when (which) {
                        0 -> 1
                        1 -> 3
                        2 -> 7
                        else -> 1
                    }
                    setEventReminder(event, reminderDays)
                }
                .show()
        }
    }

    private fun setEventReminder(event: SeasonalEvent, daysBefore: Int) {
        // Calculate reminder time
        val reminderTime = Calendar.getInstance().apply {
            time = event.startDate
            add(Calendar.DAY_OF_YEAR, -daysBefore)
        }.timeInMillis

        // Create intent to open app when notification is clicked
        val intent = Intent(requireContext(), MainActivity::class.java).apply {
            putExtra("eventId", event.id)
        }

        // Here you would normally create an alarm or use WorkManager
        // For simplicity, we'll just show a confirmation
        Snackbar.make(
            binding.root,
            "Reminder set for ${DateUtils.formatDate(Date(reminderTime))}",
            Snackbar.LENGTH_LONG
        ).show()

        // In a real implementation, you'd use NotificationManager, AlarmManager, or WorkManager
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}