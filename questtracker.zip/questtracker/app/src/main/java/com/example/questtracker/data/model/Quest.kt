package com.example.questtracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "quests")
data class Quest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val questType: QuestType,
    val questGiver: String,
    val location: String,
    val expansion: FFXIVExpansion,
    val requiredLevel: Int,
    val isCompleted: Boolean = false,
    val isSeasonal: Boolean = false,
    val seasonalEventName: String? = null,
    val startDate: Date,
    val endDate: Date? = null,
    val completedDate: Date? = null,
    // For tracking time spent on quest
    val timeSpentSeconds: Long = 0,
    val lastActiveTimestamp: Long? = null,
    // Remote ID from API
    val remoteId: String? = null,
    // FFXIV specific fields
    val rewards: String? = null,
    val unlocks: String? = null,
    val prerequisites: String? = null,
    val questMarkerPosition: String? = null,
    val requiredItemLevel: Int? = null
)