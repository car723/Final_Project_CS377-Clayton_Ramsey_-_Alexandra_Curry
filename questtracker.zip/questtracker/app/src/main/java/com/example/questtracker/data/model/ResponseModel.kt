package com.example.questtracker.data.model

import com.google.gson.annotations.SerializedName

data class CharacterSearchResponse(
    val pagination: Pagination,
    val results: List<CharacterSearchResult>
)

data class Pagination(
    val page: Int,
    val pageNext: Int?,
    val pagePrev: Int?,
    val pageTotal: Int,
    val results: Int,
    val resultsPerPage: Int,
    val resultsTotal: Int
)

data class CharacterSearchResult(
    val avatar: String,
    val feastMatches: Int,
    val id: Long,
    val lang: String?,
    val name: String,
    val rank: String?,
    val rankIcon: String?,
    val server: String
)

data class CharacterResponse(
    val achievement: AchievementData?,
    val achievements: AchievementsData?,
    val character: CharacterData,
    @SerializedName("Info")
    val info: InfoData?
)

data class AchievementData(
    val count: Int,
    val points: Int
)

data class AchievementsData(
    val list: List<Achievement>,
    val points: Int
)

data class Achievement(
    val date: Long,
    val id: Int,
    val icon: String?,
    val name: String?,
    val points: Int?
)

data class CharacterData(
    val activeClassJob: ClassJob?,
    val avatar: String,
    val bio: String,
    val classJobs: List<CharacterClassJob>?,
    val dc: String,
    val freeCompanyId: String?,
    val freeCompanyName: String?,
    val gearSet: GearSet?,
    val gender: Int,
    val grandCompany: GrandCompany?,
    val id: Long,
    val name: String,
    val nameday: String,
    val parseDate: Long,
    val portrait: String,
    val pvpTeamId: String?,
    val race: Race?,
    val server: String,
    val title: Int?,
    val titleTop: Boolean?,
    val town: Int?,
    val tribe: Tribe?
)

data class CharacterClassJob(
    val classID: Int,
    val expLevel: Int,
    val expLevelMax: Int,
    val expLevelTogo: Int,
    val isSpecialised: Boolean,
    val jobID: Int,
    val level: Int,
    val name: String
)

data class ClassJob(
    val classID: Int,
    val expLevel: Int,
    val expLevelMax: Int,
    val expLevelTogo: Int,
    val isSpecialised: Boolean,
    val jobID: Int,
    val level: Int,
    val name: String
)

data class GearSet(
    val attributes: Map<String, Int>,
    val classID: Int,
    val gear: Map<String, GearItem>,
    val gearKey: String,
    val jobID: Int,
    val level: Int
)

data class GearItem(
    val creator: String?,
    val dye: Int?,
    val id: Int,
    val materia: List<Int>?,
    val mirage: Int?
)

data class GrandCompany(
    val nameID: Int,
    val rankID: Int
)

data class Race(
    val id: Int,
    val name: String
)

data class Tribe(
    val id: Int,
    val name: String
)

data class InfoData(
    val achievements: ResponseInfo?,
    val character: ResponseInfo,
    val freeCompany: ResponseInfo?,
    val freeCompanyMembers: ResponseInfo?,
    val friends: ResponseInfo?,
    val pvpTeam: ResponseInfo?
)

data class ResponseInfo(
    val cache: Boolean?,
    val state: Int?,
    val updated: Long?
)

// Quest achievements mapping
// These are the IDs of achievements that correspond to MSQ completion
object QuestAchievementIds {
    // A Realm Reborn
    const val ARR_FINAL = 1026 // The Ultimate Weapon

    // Heavensward
    const val HW_FINAL = 1484 // Heavensward

    // Stormblood
    const val SB_FINAL = 1902 // Stormblood

    // Shadowbringers
    const val SHB_FINAL = 2412 // Shadowbringers

    // Endwalker
    const val EW_FINAL = 2894 // Endwalker

    // Dawntrail
    const val DT_FINAL = 3346 // Dawntrail (estimated/placeholder)
}