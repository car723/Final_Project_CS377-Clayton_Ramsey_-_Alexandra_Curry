package com.example.questtracker.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.questtracker.R
import com.example.questtracker.data.model.Quest
import com.example.questtracker.databinding.FragmentQuestDetailBinding
import com.example.questtracker.ui.viewmodel.QuestViewModel
import com.example.questtracker.util.NotificationManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class QuestDetailFragment : Fragment() {

    private var _binding: FragmentQuestDetailBinding? = null
    private val binding get() = _binding!!

    private val args: QuestDetailFragmentArgs by navArgs()
    private val questViewModel: QuestViewModel by viewModels()

    private var quest: Quest? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentQuestDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        loadQuest()
        setupFabListener()
        observeTracking()
    }

    private fun loadQuest() {
        viewLifecycleOwner.lifecycleScope.launch {
            val loadedQuest = questViewModel.getQuestById(args.questId)
            if (loadedQuest != null) {
                quest = loadedQuest as Quest?
                updateUI(loadedQuest)
            } else {
                Toast.makeText(requireContext(), "Quest not found", Toast.LENGTH_SHORT).show()
                findNavController().navigateUp()
            }
        }
    }

    private fun updateUI(quest: Quest) {
        binding.apply {
            // Set quest basic info
            collapsingToolbar.title = quest.title
            questDescription.text = quest.description

            // Set quest type and expansion chips
            questTypeChip.text = quest.questType.name.replace("_", " ")
            questExpansionChip.text = quest.expansion.name.replace("_", " ")

            // Set quest details
            questGiver.text = quest.questGiver
            questLocation.text = quest.location
            questLevel.text = quest.requiredLevel.toString()

            // Set quest rewards
            questRewards.text = quest.rewards ?: "No specific rewards"

            // Set tracking info
            questTimeSpent.text = questViewModel.getFormattedTimeString(quest.timeSpentSeconds)

            // Set completion status
            val statusColor = if (quest.isCompleted) {
                ContextCompat.getColor(requireContext(), R.color.quest_complete)
            } else {
                ContextCompat.getColor(requireContext(), R.color.quest_incomplete)
            }
            questTypeChip.chipBackgroundColor = ContextCompat.getColorStateList(requireContext(),
                if (quest.isCompleted) R.color.quest_complete_bg else R.color.quest_incomplete_bg)

            // Set FAB text based on tracking status
            updateFabState(questViewModel.isTracking.value == true &&
                    questViewModel.activeTrackedQuestId.value == quest.id)

            // Set image based on quest type
            val imageResId = when (quest.questType) {
                com.example.questtracker.data.model.QuestType.MAIN_SCENARIO -> R.drawable.img_msq
                com.example.questtracker.data.model.QuestType.SEASONAL_EVENT -> R.drawable.img_seasonal_quest
                com.example.questtracker.data.model.QuestType.ALLIANCE_RAID -> R.drawable.img_alliance_raid
                com.example.questtracker.data.model.QuestType.NORMAL_RAID -> R.drawable.img_normal_raid
                com.example.questtracker.data.model.QuestType.CLASS_JOB_QUEST -> R.drawable.img_job_quest
                else -> R.drawable.img_side_quest
            }
            questImage.setImageResource(imageResId)
        }
    }

    private fun setupFabListener() {
        binding.fabTrackTime.setOnClickListener {
            val isTracking = questViewModel.isTracking.value == true &&
                    questViewModel.activeTrackedQuestId.value == quest?.id

            if (isTracking) {
                questViewModel.stopTrackingQuest()
            } else {
                // Stop tracking current quest if any
                if (questViewModel.isTracking.value == true) {
                    questViewModel.stopTrackingQuest()
                }

                // Start tracking this quest
                quest?.let { q ->
                    questViewModel.startTrackingQuest(q.id)
                }
            }
        }
    }

    private fun observeTracking() {
        questViewModel.isTracking.observe(viewLifecycleOwner) { isTracking ->
            val isTrackingThisQuest = isTracking &&
                    questViewModel.activeTrackedQuestId.value == quest?.id
            updateFabState(isTrackingThisQuest)
        }

        questViewModel.activeTrackedQuestId.observe(viewLifecycleOwner) { activeQuestId ->
            val isTrackingThisQuest = questViewModel.isTracking.value == true &&
                    activeQuestId == quest?.id
            updateFabState(isTrackingThisQuest)
        }

        questViewModel.elapsedTime.observe(viewLifecycleOwner) { elapsedTime ->
            if (questViewModel.isTracking.value == true &&
                questViewModel.activeTrackedQuestId.value == quest?.id) {
                binding.questTimeSpent.text = questViewModel.getFormattedTimeString(elapsedTime)
            }
        }
    }

    private fun updateFabState(isTrackingThisQuest: Boolean) {
        binding.fabTrackTime.apply {
            if (isTrackingThisQuest) {
                text = getString(R.string.stop_tracking)
                icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_stop)
            } else {
                text = getString(R.string.start_tracking)
                icon = ContextCompat.getDrawable(requireContext(), R.drawable.ic_timer)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_quest_detail, menu)
        // Update the complete/incomplete menu item
        menu.findItem(R.id.action_complete_quest)?.apply {
            setTitle(if (quest?.isCompleted == true) R.string.mark_incomplete else R.string.mark_complete)
            setIcon(if (quest?.isCompleted == true) R.drawable.ic_incomplete else R.drawable.ic_complete)
        }

        super.onCreateOptionsMenu(menu, inflater)
    }

    @Deprecated("Deprecated in Java")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_complete_quest -> {
                toggleQuestCompletion()
                true
            }
            R.id.action_delete_quest -> {
                confirmDeleteQuest()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun toggleQuestCompletion() {
        quest?.let { q ->
            val updatedQuest = q.copy(isCompleted = !q.isCompleted)
            questViewModel.updateQuest(updatedQuest)
            quest = updatedQuest

            // If quest is completed, cancel any tracking notifications
            if (updatedQuest.isCompleted) {
                notificationManager.cancelNotification(q.id.toInt() + 10000) // Using the same offset as in NotificationManager
            }

            // Update UI
            updateUI(updatedQuest)
            activity?.invalidateOptionsMenu()

            // Show success message
            val message = if (updatedQuest.isCompleted) {
                "Quest marked as completed"
            } else {
                "Quest marked as incomplete"
            }
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        }
    }

    private fun confirmDeleteQuest() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Quest")
            .setMessage("Are you sure you want to delete this quest? This action cannot be undone.")
            .setPositiveButton("Delete") { _, _ ->
                deleteQuest()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    @Inject
    lateinit var notificationManager: NotificationManager

    private fun deleteQuest() {
        quest?.let { q ->
            questViewModel.deleteQuest(q)
            notificationManager.cancelNotification(q.id.toInt())
            Toast.makeText(requireContext(), "Quest deleted", Toast.LENGTH_SHORT).show()
            findNavController().navigateUp()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}