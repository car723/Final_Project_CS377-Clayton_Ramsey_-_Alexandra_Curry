package com.example.questtracker.data.remote

import com.example.questtracker.BuildConfig
import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class XIVApiClient @Inject constructor() {
    // The base URL for XIVAPI
    private val baseUrl = BuildConfig.XIVAPI_URL

    // API key from BuildConfig
    private val apiKey = BuildConfig.XIVAPI_KEY

    fun getApiKey(): String = apiKey

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(HttpLoggingInterceptor().apply {
            level = if (BuildConfig.ENABLE_LOGGING)
                HttpLoggingInterceptor.Level.BODY
            else
                HttpLoggingInterceptor.Level.NONE
        })
        .addInterceptor { chain ->
            // Add API key to all requests if it's not already there
            val original = chain.request()
            val originalUrl = original.url

            val url = if (!originalUrl.queryParameterNames.contains("private_key")) {
                originalUrl.newBuilder()
                    .addQueryParameter("private_key", apiKey)
                    .build()
            } else {
                originalUrl
            }

            val request = original.newBuilder()
                .url(url)
                .build()

            chain.proceed(request)
        }
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val gson = GsonBuilder()
        .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        .create()

    private val retrofit = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create(gson))
        .build()

    val ffxivApi: FFXIVApi = retrofit.create(FFXIVApi::class.java)

    // For internal app API
    private val appApiRetrofit = Retrofit.Builder()
        .baseUrl(BuildConfig.API_BASE_URL)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create(gson))
        .build()

    val appApi: FFXIVApi = appApiRetrofit.create(FFXIVApi::class.java)
}