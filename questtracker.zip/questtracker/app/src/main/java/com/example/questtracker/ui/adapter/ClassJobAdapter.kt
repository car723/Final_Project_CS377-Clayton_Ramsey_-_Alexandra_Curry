package com.example.questtracker.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.questtracker.R
import com.example.questtracker.data.model.CharacterClassJob
import com.example.questtracker.databinding.ItemClassJobBinding

class ClassJobAdapter(
    private val onTrackProgress: (CharacterClassJob) -> Unit
) : ListAdapter<CharacterClassJob, ClassJobAdapter.ClassJobViewHolder>(ClassJobDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ClassJobViewHolder {
        val binding = ItemClassJobBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ClassJobViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ClassJobViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ClassJobViewHolder(
        private val binding: ItemClassJobBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.btnTrackProgress.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onTrackProgress(getItem(position))
                }
            }
        }

        fun bind(classJob: CharacterClassJob): String {
            val context = binding.root.context
            binding.apply {
                jobName.text = classJob.name
                jobLevel.text = classJob.level.toString()

                // Set the job category based on the job ID
                val jobCategory = getJobCategory(classJob.jobID)
                return jobCategory

                // Set the progress bar
                expProgress.progress = calculateExpPercentage(
                    classJob.expLevel,
                    classJob.expLevelMax
                )

                // Set the indicator color based on job category
                val indicatorColor = when (jobCategory) {
                    "Tank" -> ContextCompat.getColor(context, R.color.job_tank)
                    "Healer" -> ContextCompat.getColor(context, R.color.job_healer)
                    "DPS" -> ContextCompat.getColor(context, R.color.job_dps)
                    "Limited" -> ContextCompat.getColor(context, R.color.job_limited)
                    "Crafter" -> ContextCompat.getColor(context, R.color.job_crafter)
                    "Gatherer" -> ContextCompat.getColor(context, R.color.job_gatherer)
                    else -> ContextCompat.getColor(context, R.color.ffxiv_blue)
                }

                jobTypeIndicator.setBackgroundColor(indicatorColor)
                expProgress.progressTintList = ContextCompat.getColorStateList(context, getColorResourceForCategory(jobCategory))

                // Set job icon
                jobIcon.setImageResource(getIconResourceForJob(classJob.jobID))

                // Only show track button if job is not max level
                btnTrackProgress.isEnabled = classJob.level < 90
                btnTrackProgress.alpha = if (classJob.level < 90) 1.0f else 0.5f
            }
        }

        private fun getJobCategory(jobId: Int): String {
            return when (jobId) {
                // Tanks
                19, 21, 32, 37 -> "Tank"
                // Healers
                24, 28, 33, 40 -> "Healer"
                // Melee DPS
                20, 22, 30, 34 -> "DPS"
                // Ranged Physical DPS
                23, 31, 38 -> "DPS"
                // Ranged Magical DPS
                25, 27, 35, 36 -> "DPS"
                // Limited
                36 -> "Limited"
                // Disciples of the Hand (Crafters)
                8, 9, 10, 11, 12, 13, 14, 15 -> "Crafter"
                // Disciples of the Land (Gatherers)
                16, 17, 18 -> "Gatherer"
                // Base classes that upgrade to jobs
                1, 2, 3, 4, 5, 6, 7, 26, 29 -> "DPS"
                else -> "Unknown"
            }
        }

        private fun calculateExpPercentage(current: Int, max: Int): Int {
            return if (max > 0) (current.toFloat() / max.toFloat() * 100).toInt() else 0
        }

        private fun getColorResourceForCategory(category: String): Int {
            return when (category) {
                "Tank" -> R.color.job_tank
                "Healer" -> R.color.job_healer
                "DPS" -> R.color.job_dps
                "Limited" -> R.color.job_limited
                "Crafter" -> R.color.job_crafter
                "Gatherer" -> R.color.job_gatherer
                else -> R.color.ffxiv_blue
            }
        }

        private fun getIconResourceForJob(jobId: Int): Int {
            // Use existing drawables instead of missing ones
            return when (jobId) {
                // Tanks
                19, 21, 32, 37 -> R.drawable.ic_quest_complete // Placeholder for tank icons
                // Healers
                24, 28, 33, 40 -> R.drawable.ic_quest_incomplete // Placeholder for healer icons
                // Other jobs...
                else -> R.drawable.ic_quest_incomplete // Default icon
            }
        }
    }

    private class ClassJobDiffCallback : DiffUtil.ItemCallback<CharacterClassJob>() {
        override fun areItemsTheSame(oldItem: CharacterClassJob, newItem: CharacterClassJob): Boolean {
            return oldItem.classID == newItem.classID && oldItem.jobID == newItem.jobID
        }

        override fun areContentsTheSame(oldItem: CharacterClassJob, newItem: CharacterClassJob): Boolean {
            return oldItem == newItem
        }
    }
}