package com.example.questtracker.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.questtracker.R
import com.example.questtracker.data.model.CharacterSearchResult
import com.example.questtracker.databinding.ItemCharacterSearchBinding

class CharacterSearchAdapter(
    private val onCharacterSelected: (CharacterSearchResult) -> Unit
) : ListAdapter<CharacterSearchResult, CharacterSearchAdapter.CharacterViewHolder>(CharacterDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CharacterViewHolder {
        val binding = ItemCharacterSearchBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return CharacterViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CharacterViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CharacterViewHolder(
        private val binding: ItemCharacterSearchBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onCharacterSelected(getItem(position))
                }
            }
        }

        fun bind(character: CharacterSearchResult) {
            binding.apply {
                characterName.text = character.name
                characterServer.text = character.server

                // You would typically load the avatar with an image loading library
                // For now we'll use a placeholder
                characterAvatar.setImageResource(R.drawable.ic_quest_list)

                // Handle rank if available
                if (!character.rank.isNullOrEmpty()) {
                    characterRank.text = character.rank
                    characterRank.visibility = android.view.View.VISIBLE
                } else {
                    characterRank.visibility = android.view.View.GONE
                }
            }
        }
    }

    private class CharacterDiffCallback : DiffUtil.ItemCallback<CharacterSearchResult>() {
        override fun areItemsTheSame(oldItem: CharacterSearchResult, newItem: CharacterSearchResult): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: CharacterSearchResult, newItem: CharacterSearchResult): Boolean {
            return oldItem == newItem
        }
    }
}