package com.example.questtracker.util

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.annotation.RequiresPermission
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.questtracker.R
import com.example.questtracker.data.model.SeasonalEvent
import com.example.questtracker.ui.activity.MainActivity
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val notificationManager: NotificationManagerCompat = NotificationManagerCompat.from(context)

    companion object {
        const val CHANNEL_EVENTS = "seasonal_events_channel"
        const val CHANNEL_QUEST_TRACKING = "quest_tracking_channel"
        const val CHANNEL_UPDATES = "updates_channel"

        const val NOTIFICATION_GROUP_EVENTS = "group_events"
        const val NOTIFICATION_GROUP_QUESTS = "group_quests"
    }

    init {
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Seasonal Events channel
            val eventChannel = NotificationChannel(
                CHANNEL_EVENTS,
                "Seasonal Events",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for FFXIV seasonal events"
                enableVibration(true)
                enableLights(true)
            }

            // Quest Tracking channel
            val questTrackingChannel = NotificationChannel(
                CHANNEL_QUEST_TRACKING,
                "Quest Tracking",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifications for quest tracking status"
                enableVibration(false)
                setShowBadge(false)
            }

            // Updates channel
            val updatesChannel = NotificationChannel(
                CHANNEL_UPDATES,
                "App Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Notifications for app updates and news"
            }

            // Register all channels
            val systemNotificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            systemNotificationManager.createNotificationChannels(
                listOf(eventChannel, questTrackingChannel, updatesChannel)
            )
        }
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    fun showEventNotification(event: SeasonalEvent) {
        // Create the intent to open the app
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("eventId", event.id)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            event.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Build the notification
        val notification = NotificationCompat.Builder(context, CHANNEL_EVENTS)
            .setSmallIcon(R.drawable.ic_seasonal_event)
            .setContentTitle(event.name)
            .setContentText("${event.name} is now active!")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setContentIntent(pendingIntent)
            .setGroup(NOTIFICATION_GROUP_EVENTS)
            .setAutoCancel(true)
            .build()

        // Show the notification if we have permission
        if (hasNotificationPermission()) {
            notificationManager.notify(event.id.toInt(), notification)
        }
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    fun showQuestTrackingNotification(questId: Long, questTitle: String, isTracking: Boolean) {
        // Create the intent to open the quest detail
        val intent = Intent(context, MainActivity::class.java).apply {
            putExtra("questId", questId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            questId.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Build the notification
        val notification = NotificationCompat.Builder(context, CHANNEL_QUEST_TRACKING)
            .setSmallIcon(R.drawable.ic_timer)
            .setContentTitle(questTitle)
            .setContentText(if (isTracking) "Now tracking quest time" else "Quest tracking stopped")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .setGroup(NOTIFICATION_GROUP_QUESTS)
            .setOngoing(isTracking) // Make it ongoing if we're tracking
            .setAutoCancel(!isTracking)
            .build()

        // Show the notification if we have permission
        if (hasNotificationPermission()) {
            notificationManager.notify(questId.toInt() + 10000, notification) // Offset to avoid ID conflicts
        }
    }

    private fun hasNotificationPermission(): Boolean {
        // For Android 13+, we need to check for the POST_NOTIFICATIONS permission
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            // For older versions, permission is granted at install time
            true
        }
    }

    fun cancelNotification(notificationId: Int) {
        notificationManager.cancel(notificationId)
    }

    fun cancelAllNotifications() {
        notificationManager.cancelAll()
    }
}