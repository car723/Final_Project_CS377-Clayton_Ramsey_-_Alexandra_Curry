package com.example.questtracker.ui.viewmodel

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.questtracker.data.model.FFXIVExpansion
import com.example.questtracker.data.model.Quest
import com.example.questtracker.data.model.QuestType
import com.example.questtracker.data.repository.QuestRepository
import com.example.questtracker.service.QuestTimerService
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@HiltViewModel
class QuestViewModel @Inject constructor(
    private val questRepository: QuestRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    // Quest tracking state
    private val _activeTrackedQuestId = MutableLiveData<Long?>(null)
    val activeTrackedQuestId: LiveData<Long?> = _activeTrackedQuestId

    private val _activeTrackedQuest = MutableLiveData<Quest?>(null)
    val activeTrackedQuest: LiveData<Quest?> = _activeTrackedQuest

    private val _trackingStartTime = MutableLiveData<Long>(0)
    private val _elapsedTime = MutableLiveData<Long>(0)
    val elapsedTime: LiveData<Long> = _elapsedTime

    private val _isTracking = MutableLiveData<Boolean>(false)
    val isTracking: LiveData<Boolean> = _isTracking

    // Quest lists
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedExpansion = MutableStateFlow<FFXIVExpansion?>(null)
    val selectedExpansion = _selectedExpansion.asStateFlow()

    private val _selectedQuestType = MutableStateFlow<QuestType?>(null)
    val selectedQuestType = _selectedQuestType.asStateFlow()

    private val _selectedSeasonalEvent = MutableStateFlow<String?>(null)
    val selectedSeasonalEvent = _selectedSeasonalEvent.asStateFlow()

    // Filtered quests based on search and filters
    val filteredQuests = combine(
        _searchQuery,
        _selectedExpansion,
        _selectedQuestType,
        _selectedSeasonalEvent,
        questRepository.getAllQuests()
    ) { query, expansion, type, seasonalEvent, quests ->
        quests.filter { quest ->
            val matchesSearch = query.isEmpty() ||
                    quest.title.contains(query, ignoreCase = true) ||
                    quest.description.contains(query, ignoreCase = true)

            val matchesExpansion = expansion == null || quest.expansion == expansion

            val matchesType = type == null || quest.questType == type

            val matchesSeasonalEvent = seasonalEvent == null ||
                    (quest.isSeasonal && quest.seasonalEventName == seasonalEvent)

            matchesSearch && matchesExpansion && matchesType && matchesSeasonalEvent
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Active quests
    val activeQuests = questRepository.getActiveQuests()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Seasonal quests
    val seasonalQuests = questRepository.getSeasonalQuests()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Functions for interacting with quests
    suspend fun getQuestById(questId: Long): Quest? {
        return questRepository.getQuestById(questId)
    }

    fun searchQuests(query: String) {
        _searchQuery.value = query
    }

    fun filterByExpansion(expansion: FFXIVExpansion?) {
        _selectedExpansion.value = expansion
    }

    fun filterByQuestType(type: QuestType?) {
        _selectedQuestType.value = type
    }

    fun filterBySeasonalEvent(eventName: String?) {
        _selectedSeasonalEvent.value = eventName
    }

    fun addQuest(quest: Quest) {
        viewModelScope.launch {
            questRepository.insertQuest(quest)
        }
    }

    fun updateQuest(quest: Quest) {
        viewModelScope.launch {
            questRepository.updateQuest(quest)
        }
    }

    fun deleteQuest(quest: Quest) {
        viewModelScope.launch {
            questRepository.deleteQuest(quest)
        }
    }

    fun markQuestAsCompleted(quest: Quest) {
        viewModelScope.launch {
            val updatedQuest = quest.copy(
                isCompleted = true,
                completedDate = Date()
            )
            questRepository.updateQuest(updatedQuest)
        }
    }

    fun fetchQuests() {
        viewModelScope.launch {
            questRepository.fetchAndSaveQuests()
        }
    }

    fun getQuestsBySeasonalEvent(eventName: String): Flow<List<Quest>> {
        return questRepository.getQuestsBySeasonalEvent(eventName)
    }

    // Functions for tracking time spent on quests
    fun startTrackingQuest(questId: Long) {
        viewModelScope.launch {
            val quest = questRepository.getQuestById(questId)
            quest?.let {
                // Create and start the quest timer service
                val intent = Intent(context, QuestTimerService::class.java).apply {
                    action = QuestTimerService.ACTION_START_TRACKING
                    putExtra(QuestTimerService.EXTRA_QUEST_ID, questId)
                    putExtra(QuestTimerService.EXTRA_QUEST_TITLE, it.title)
                }
                context.startService(intent)

                // Update UI state
                _activeTrackedQuestId.value = questId
                _activeTrackedQuest.value = quest
                _isTracking.value = true
            }
        }
    }

    fun stopTrackingQuest() {
        viewModelScope.launch {
            val questId = _activeTrackedQuestId.value
            if (questId != null && _isTracking.value == true) {
                val startTime = _trackingStartTime.value ?: 0
                val endTime = System.currentTimeMillis()
                val timeSpentSeconds = (endTime - startTime) / 1000

                // Add the time to the database
                questRepository.updateQuestTime(questId, timeSpentSeconds)

                // If the quest has a remote ID, send the time to the server
                _activeTrackedQuest.value?.remoteId?.let { remoteId ->
                    questRepository.trackQuestTimeOnServer(remoteId, timeSpentSeconds)
                }

                // Reset tracking state
                _isTracking.value = false
                _activeTrackedQuestId.value = null
                _activeTrackedQuest.value = null
                _trackingStartTime.value = 0
                _elapsedTime.value = 0
            }
        }
    }

    fun pauseTrackingQuest() {
        if (_isTracking.value == true) {
            val startTime = _trackingStartTime.value ?: 0
            val endTime = System.currentTimeMillis()
            val timeSpentMillis = endTime - startTime
            _elapsedTime.value = (_elapsedTime.value ?: 0) + timeSpentMillis / 1000
            _isTracking.value = false
        }
    }

    fun resumeTrackingQuest() {
        if (_isTracking.value?.let { !it == true } == true && _activeTrackedQuestId.value != null) {
            _trackingStartTime.value = System.currentTimeMillis()
            _isTracking.value = true
        }
    }

    fun getRecentlyTrackedQuests(): Flow<List<Quest>> {
        return questRepository.getRecentlyTrackedQuests()
    }

    // Function to get formatted time string (HH:MM:SS)
    @SuppressLint("DefaultLocale")
    fun getFormattedTimeString(seconds: Long): String {
        val hours = seconds / 3600
        val minutes = (seconds % 3600) / 60
        val secs = seconds % 60
        return String.format("%02d:%02d:%02d", hours, minutes, secs)
    }

    // Clean up when the ViewModel is cleared
    override fun onCleared() {
        super.onCleared()
        if (_isTracking.value == true) {
            stopTrackingQuest()
        }
    }
}