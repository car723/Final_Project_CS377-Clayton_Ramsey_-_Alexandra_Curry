package com.example.questtracker.ui.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.questtracker.R
import com.example.questtracker.data.model.Quest
import com.example.questtracker.databinding.FragmentTimeTrackerBinding
import com.example.questtracker.ui.adapter.QuestAdapter
import com.example.questtracker.ui.viewmodel.QuestViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

@AndroidEntryPoint
class TimeTrackerFragment : Fragment() {

    private var _binding: FragmentTimeTrackerBinding? = null
    private val binding get() = _binding!!

    private val args: TimeTrackerFragmentArgs by navArgs()
    private val questViewModel: QuestViewModel by viewModels()

    private lateinit var questAdapter: QuestAdapter
    private val handler = Handler(Looper.getMainLooper())
    private val timeUpdateRunnable = object : Runnable {
        override fun run() {
            updateElapsedTime()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTimeTrackerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupTrackedQuestObservers()
        setupButtonListeners()
        loadQuestIfProvided()
        loadRecentQuests()
    }

    private fun setupRecyclerView() {
        questAdapter = QuestAdapter(
            onQuestClicked = { quest ->
                navigateToQuestDetail(quest)
            },
            onTrackClicked = { quest ->
                startTrackingQuest(quest)
            }
        )

        binding.recyclerRecentQuests.apply {
            adapter = questAdapter
            layoutManager = LinearLayoutManager(requireContext())
            addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))
        }
    }

    private fun setupTrackedQuestObservers() {
        questViewModel.activeTrackedQuest.observe(viewLifecycleOwner) { quest ->
            if (quest != null) {
                updateActiveQuestUI(quest)
                binding.cardActiveQuest.visibility = View.VISIBLE
                binding.emptyView.visibility = View.GONE
            } else {
                binding.cardActiveQuest.visibility = View.GONE
                binding.emptyView.visibility = View.VISIBLE
            }
        }

        questViewModel.isTracking.observe(viewLifecycleOwner) { isTracking ->
            updateTrackingControls(isTracking)
            if (isTracking) {
                startTimeUpdates()
            } else {
                stopTimeUpdates()
            }
        }
    }

    private fun setupButtonListeners() {
        binding.btnPause.setOnClickListener {
            if (questViewModel.isTracking.value == true) {
                questViewModel.pauseTrackingQuest()
            } else {
                questViewModel.resumeTrackingQuest()
            }
        }

        binding.btnStop.setOnClickListener {
            questViewModel.stopTrackingQuest()
        }
    }

    private fun loadQuestIfProvided() {
        if (args.questId != -1L) {
            viewLifecycleOwner.lifecycleScope.launch {
                val quest = questViewModel.getQuestById(args.questId)
                if (quest != null) {
                    startTrackingQuest(quest)
                }
            }
        }
    }

    private fun loadRecentQuests() {
        viewLifecycleOwner.lifecycleScope.launch {
            // Get recently tracked quests
            val recentQuests = questViewModel.getRecentlyTrackedQuests().first()
            questAdapter.submitList(recentQuests)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateActiveQuestUI(quest: Quest) {
        binding.apply {
            activeQuestTitle.text = quest.title
            activeQuestType.text = "${quest.questType.name.replace("_", " ")} - ${quest.expansion.name.replace("_", " ")}"
        }
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun updateTrackingControls(isTracking: Boolean) {
        binding.apply {
            btnPause.text = if (isTracking) getString(R.string.pause) else getString(R.string.resume)
        }
    }

    private fun updateElapsedTime() {
        val elapsedTime = questViewModel.elapsedTime.value ?: 0
        binding.timeElapsed.text = questViewModel.getFormattedTimeString(elapsedTime)
    }

    private fun startTrackingQuest(quest: Quest) {
        if (questViewModel.isTracking.value == true) {
            questViewModel.stopTrackingQuest()
        }
        questViewModel.startTrackingQuest(quest.id)
    }

    private fun navigateToQuestDetail(quest: Quest) {
        val action = TimeTrackerFragmentDirections
            .actionTimeTrackerFragmentToQuestDetailFragment(quest.id)
        findNavController().navigate(action)
    }

    private fun startTimeUpdates() {
        handler.post(timeUpdateRunnable)
    }

    private fun stopTimeUpdates() {
        handler.removeCallbacks(timeUpdateRunnable)
    }

    override fun onPause() {
        super.onPause()
        stopTimeUpdates()
    }

    override fun onResume() {
        super.onResume()
        if (questViewModel.isTracking.value == true) {
            startTimeUpdates()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        stopTimeUpdates()
        _binding = null
    }
}