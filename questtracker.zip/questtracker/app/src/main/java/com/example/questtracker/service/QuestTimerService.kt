package com.example.questtracker.service

import android.Manifest
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.util.Log
import androidx.annotation.RequiresPermission
import com.example.questtracker.data.repository.QuestRepository
import com.example.questtracker.util.NotificationManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class QuestTimerService : Service() {
    @Inject
    lateinit var questRepository: QuestRepository

    @Inject
    lateinit var notificationManager: NotificationManager

    private val serviceJob = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + serviceJob)

    private var activeQuestId: Long? = null
    private var activeQuestTitle: String? = null
    private var startTimeMillis: Long = 0
    private var isTracking = false
    private var elapsedSeconds: Long = 0

    private val binder = LocalBinder()

    // For binding to service
    inner class LocalBinder : Binder() {
        fun getService(): QuestTimerService = this@QuestTimerService
    }

    override fun onBind(intent: Intent?): IBinder {
        return binder
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "QuestTimerService created")
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_TRACKING -> {
                val questId = intent.getLongExtra(EXTRA_QUEST_ID, -1L)
                val questTitle = intent.getStringExtra(EXTRA_QUEST_TITLE) ?: "Unknown Quest"

                if (questId != -1L) {
                    startTracking(questId, questTitle)
                }
            }

            ACTION_STOP_TRACKING -> {
                stopTracking()
            }

            ACTION_PAUSE_TRACKING -> {
                pauseTracking()
            }

            ACTION_RESUME_TRACKING -> {
                resumeTracking()
            }
        }

        return START_STICKY
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    fun startTracking(questId: Long, questTitle: String) {
        // If we're already tracking, stop first
        if (isTracking && activeQuestId != null) {
            stopTracking()
        }

        // Set up new tracking session
        activeQuestId = questId
        activeQuestTitle = questTitle
        startTimeMillis = System.currentTimeMillis()
        isTracking = true
        elapsedSeconds = 0

        // Start time tracking
        startTimeUpdates()

        // Show notification
        notificationManager.showQuestTrackingNotification(
            questId,
            questTitle,
            true // isTracking = true
        )

        Log.d(TAG, "Started tracking quest: $questTitle ($questId)")
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    fun stopTracking() {
        if (!isTracking || activeQuestId == null) return

        val questId = activeQuestId ?: return
        val title = activeQuestTitle ?: "Unknown Quest"

        // Calculate final elapsed time
        val endTimeMillis = System.currentTimeMillis()
        val elapsedMillis = endTimeMillis - startTimeMillis
        val seconds = elapsedMillis / 1000

        // Save the elapsed time to the database
        serviceScope.launch {
            try {
                questRepository.updateQuestTime(questId, seconds + elapsedSeconds)
                questRepository.updateLastActiveTimestamp(questId, System.currentTimeMillis())

                // If the quest has a remote ID, update it on the server as well
                val quest = questRepository.getQuestById(questId)
                quest?.remoteId?.let { remoteId ->
                    try {
                        questRepository.trackQuestTimeOnServer(remoteId, seconds + elapsedSeconds)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to update time on server: ${e.message}", e)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error saving quest time: ${e.message}", e)
            }
        }

        // Reset tracking state
        isTracking = false
        activeQuestId = null
        activeQuestTitle = null
        elapsedSeconds = 0

        // Update notification
        notificationManager.showQuestTrackingNotification(
            questId,
            title,
            false
        )

        Log.d(TAG, "Stopped tracking quest: $title ($questId)")
    }

    fun pauseTracking() {
        if (!isTracking || activeQuestId == null) return

        // Calculate elapsed time so far
        val currentTime = System.currentTimeMillis()
        val sessionTime = (currentTime - startTimeMillis) / 1000
        elapsedSeconds += sessionTime

        // Update start time for future resume
        startTimeMillis = currentTime

        // Set pause state
        isTracking = false

        Log.d(TAG, "Paused tracking quest: $activeQuestTitle ($activeQuestId)")
    }

    fun resumeTracking() {
        if (isTracking || activeQuestId == null) return

        // Reset start time to now
        startTimeMillis = System.currentTimeMillis()

        // Resume tracking
        isTracking = true

        Log.d(TAG, "Resumed tracking quest: $activeQuestTitle ($activeQuestId)")
    }

    fun getTotalTrackedTime(): Long {
        if (!isTracking || activeQuestId == null) return elapsedSeconds

        val currentTime = System.currentTimeMillis()
        val currentSession = (currentTime - startTimeMillis) / 1000
        return elapsedSeconds + currentSession
    }

    private fun startTimeUpdates() {
        serviceScope.launch {
            while (isActive && isTracking) {
                // Report elapsed time every second
                delay(1000)

                // Calculate current elapsed time
                val currentTime = System.currentTimeMillis()
                val currentElapsed = (currentTime - startTimeMillis) / 1000 + elapsedSeconds

                Log.d(TAG, "Elapsed time: $currentElapsed seconds")

                // Every 5 minutes, save checkpoint
                if (currentElapsed % 300 == 0L && currentElapsed > 0) {
                    saveTimeCheckpoint()
                }
            }
        }
    }

    private fun saveTimeCheckpoint() {
        val questId = activeQuestId ?: return

        serviceScope.launch {
            try {
                val currentTime = System.currentTimeMillis()
                val sessionTime = (currentTime - startTimeMillis) / 1000

                // Update total elapsed time
                elapsedSeconds += sessionTime

                // Reset start time to now
                startTimeMillis = currentTime

                // Save checkpoint to the database
                questRepository.updateQuestTime(questId, elapsedSeconds)
                questRepository.updateLastActiveTimestamp(questId, currentTime)

                Log.d(TAG, "Saved time checkpoint for quest $questId: $elapsedSeconds seconds")
            } catch (e: Exception) {
                Log.e(TAG, "Error saving time checkpoint: ${e.message}", e)
            }
        }
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    override fun onDestroy() {
        // Save any pending tracking data
        if (isTracking && activeQuestId != null) {
            stopTracking()
        }

        // Clean up coroutines
        serviceJob.cancel()

        super.onDestroy()
        Log.d(TAG, "QuestTimerService destroyed")
    }

    companion object {
        private const val TAG = "QuestTimerService"

        // Action constants
        const val ACTION_START_TRACKING = "com.example.questtracker.action.START_TRACKING"
        const val ACTION_STOP_TRACKING = "com.example.questtracker.action.STOP_TRACKING"
        const val ACTION_PAUSE_TRACKING = "com.example.questtracker.action.PAUSE_TRACKING"
        const val ACTION_RESUME_TRACKING = "com.example.questtracker.action.RESUME_TRACKING"

        // Extra constants
        const val EXTRA_QUEST_ID = "quest_id"
        const val EXTRA_QUEST_TITLE = "quest_title"
    }
}