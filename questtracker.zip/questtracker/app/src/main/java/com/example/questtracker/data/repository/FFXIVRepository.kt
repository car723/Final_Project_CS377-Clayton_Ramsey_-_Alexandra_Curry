package com.example.questtracker.data.repository

import android.util.Log
import com.example.questtracker.data.model.Achievement
import com.example.questtracker.data.model.CharacterData
import com.example.questtracker.data.model.CharacterSearchResult
import com.example.questtracker.data.model.QuestAchievementIds
import com.example.questtracker.data.remote.XIVApiClient
import dagger.Provides
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FFXIVRepository @Inject constructor(
    apiClient: XIVApiClient
) {
    private val TAG = "FFXIVRepository"
    private val apiService = apiClient.ffxivApi
    private val apiKey = apiClient.getApiKey()

    fun searchCharacter(name: String, server: String): Flow<Result<List<CharacterSearchResult>>> = flow {
        try {
            val response = apiService.searchCharacter(name, server, apiKey)
            emit(Result.success(response.results))
        } catch (e: Exception) {
            Log.e(TAG, "Error searching character: ${e.message}", e)
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    fun getCharacterDetails(id: Long): Flow<Result<CharacterData?>> = flow {
        try {
            val response = apiService.getCharacter(id, "AC", 1, apiKey)
            emit(Result.success(response.character))
        } catch (e: Exception) {
            Log.e(TAG, "Error getting character details: ${e.message}", e)
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    fun getCharacterAchievements(id: Long): Flow<Result<List<Achievement>>> = flow {
        try {
            val response = apiService.getCharacter(id, "AC", 1, apiKey)
            val achievements = response.achievements?.list ?: emptyList()
            emit(Result.success(achievements))
        } catch (e: Exception) {
            Log.e(TAG, "Error getting character achievements: ${e.message}", e)
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    fun getCompletedMSQs(id: Long): Flow<Result<Map<String, Boolean>>> = flow {
        try {
            val response = apiService.getCharacter(id, "AC", 1, apiKey)
            val achievements = response.achievements?.list ?: emptyList()
            val achievementIds = achievements.map { it.id }

            val completedMSQs = mapOf(
                "A Realm Reborn" to achievementIds.contains(QuestAchievementIds.ARR_FINAL),
                "Heavensward" to achievementIds.contains(QuestAchievementIds.HW_FINAL),
                "Stormblood" to achievementIds.contains(QuestAchievementIds.SB_FINAL),
                "Shadowbringers" to achievementIds.contains(QuestAchievementIds.SHB_FINAL),
                "Endwalker" to achievementIds.contains(QuestAchievementIds.EW_FINAL),
                "Dawntrail" to achievementIds.contains(QuestAchievementIds.DT_FINAL)
            )

            emit(Result.success(completedMSQs))
        } catch (e: Exception) {
            Log.e(TAG, "Error getting completed MSQs: ${e.message}", e)
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO)

    // Data refresh functions
    fun refreshCharacterData(characterId: Long): Flow<Result<CharacterData>> = flow {
        try {
            val characterResponse = apiService.getCharacter(characterId, "ACHM", 1, apiKey)
            emit(Result.success(characterResponse.character))
        } catch (e: Exception) {
            Log.e(TAG, "Error refreshing character data: ${e.message}", e)
            emit(Result.failure(e))
        }
    }.flowOn(Dispatchers.IO).catch { e ->
        Log.e(TAG, "Uncaught error refreshing character data: ${e.message}", e)
        emit(Result.failure(e))
    }

    @Singleton
    fun provideFFXIVRepository(apiClient: XIVApiClient): FFXIVRepository {
        return FFXIVRepository(apiClient)
    }
}