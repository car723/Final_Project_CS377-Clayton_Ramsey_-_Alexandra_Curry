package com.example.questtracker.di

import android.content.Context
import com.example.questtracker.data.local.AppDatabase
import com.example.questtracker.data.local.QuestDao
import com.example.questtracker.data.local.SeasonalEventDao
import com.example.questtracker.data.remote.FFXIVApi
import com.example.questtracker.data.remote.XIVApiClient
import com.example.questtracker.data.repository.FFXIVRepository
import com.example.questtracker.data.repository.QuestRepository
import com.example.questtracker.data.repository.SeasonalEventRepository
import com.example.questtracker.util.NotificationManager
import com.example.questtracker.util.SeasonalEventManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Named
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getInstance(context)
    }

    @Provides
    @Singleton
    fun provideQuestDao(appDatabase: AppDatabase): QuestDao {
        return appDatabase.questDao()
    }

    @Provides
    @Singleton
    fun provideSeasonalEventDao(appDatabase: AppDatabase): SeasonalEventDao {
        return appDatabase.seasonalEventDao()
    }

    @Provides
    @Singleton
    fun provideXIVApiClient(): XIVApiClient {
        return XIVApiClient()
    }

    @Provides
    @Singleton
    @Named("main")
    fun provideFFXIVApi(apiClient: XIVApiClient): FFXIVApi {
        return apiClient.ffxivApi
    }

    @Provides
    @Singleton
    @Named("app")
    fun provideDsisQuestApi(apiClient: XIVApiClient): FFXIVApi {
        return apiClient.appApi
    }

    @Provides
    @Singleton
    fun provideFFXIVRepository(apiClient: XIVApiClient): FFXIVRepository {
        return FFXIVRepository(apiClient)
    }

    @Provides
    @Singleton
    fun provideQuestRepository(
        questDao: QuestDao,
        @Named("main") ffxivApi: FFXIVApi
    ): QuestRepository {
        return QuestRepository(questDao, ffxivApi)
    }

    @Provides
    @Singleton
    fun provideSeasonalEventRepository(
        seasonalEventDao: SeasonalEventDao,
        @Named("main") ffxivApi: FFXIVApi
    ): SeasonalEventRepository {
        return SeasonalEventRepository(seasonalEventDao, ffxivApi)
    }

    @Provides
    @Singleton
    fun provideNotificationManager(@ApplicationContext context: Context): NotificationManager {
        return NotificationManager(context)
    }

    @Provides
    @Singleton
    fun provideSeasonalEventManager(
        seasonalEventRepository: SeasonalEventRepository
    ): SeasonalEventManager {
        return SeasonalEventManager(seasonalEventRepository)
    }
}