package com.example.questtracker.data.repository

import com.example.questtracker.data.local.SeasonalEventDao
import com.example.questtracker.data.model.SeasonalEvent
import com.example.questtracker.data.remote.FFXIVApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.*
import javax.inject.Inject

class SeasonalEventRepository @Inject constructor(
    private val seasonalEventDao: SeasonalEventDao,
    private val ffxivApi: FFXIVApi
) {
    suspend fun getEventById(eventId: Long): SeasonalEvent? {
        return getAllEvents().first().find { it.id == eventId }
    }

    // Local database operations
    fun getAllEvents(): Flow<List<SeasonalEvent>> = seasonalEventDao.getAllEvents()

    fun getActiveEvents(): Flow<List<SeasonalEvent>> = seasonalEventDao.getActiveEvents()

    fun getUpcomingEvents(date: Date = Date()): Flow<List<SeasonalEvent>> =
        seasonalEventDao.getUpcomingEvents(date)

    suspend fun insertEvent(event: SeasonalEvent): Long =
        seasonalEventDao.insertEvent(event)

    suspend fun updateEvent(event: SeasonalEvent) =
        seasonalEventDao.updateEvent(event)

    suspend fun deleteEvent(event: SeasonalEvent) =
        seasonalEventDao.deleteEvent(event)

    suspend fun updateActiveStatus() =
        seasonalEventDao.updateActiveStatus(Date())

    // Remote API operations
    suspend fun fetchAndSaveSeasonalEvents() {
        try {
            val remoteEvents = ffxivApi.getSeasonalEvents()
            seasonalEventDao.insertEvents(remoteEvents)
            updateActiveStatus()
        } catch (_: Exception) {
            // Handle error
        }
    }

    suspend fun fetchAndSaveActiveSeasonalEvents() {
        try {
            val remoteEvents = ffxivApi.getActiveSeasonalEvents()
            seasonalEventDao.insertEvents(remoteEvents)
            updateActiveStatus()
        } catch (_: Exception) {
            // Handle error
        }
    }

    suspend fun fetchAndSaveUpcomingSeasonalEvents() {
        try {
            val remoteEvents = ffxivApi.getUpcomingSeasonalEvents()
            seasonalEventDao.insertEvents(remoteEvents)
        } catch (_: Exception) {
            // Handle error
        }
    }

    suspend fun fetchEventDetails(eventName: String): SeasonalEvent? {
        return try {
            val event = ffxivApi.getEventDetails(eventName)
            seasonalEventDao.insertEvent(event)
            event
        } catch (_: Exception) {
            // Handle error
            null
        }
    }

    // Function to initialize with hardcoded FFXIV seasonal events for 2025
    suspend fun initializeWithDefaultEvents() {
        Date()

        val events = listOf(
            SeasonalEvent(
                name = "Heavensturn",
                description = "New Year celebration in FFXIV",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.DECEMBER, 31, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2026, Calendar.JANUARY, 15, 7, 59, 0)
                }.time,
                rewards = "Zodiac-themed items and decorations",
                questStartLocation = "Limsa Lominsa Upper Decks (X:11.5, Y:13.8)",
                minimumLevel = 15,
                isActive = false
            ),
            SeasonalEvent(
                name = "Valentione's Day",
                description = "FFXIV's Valentine's Day celebration",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.FEBRUARY, 5, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.FEBRUARY, 19, 7, 59, 0)
                }.time,
                rewards = "Heart-themed items and emotes",
                questStartLocation = "Old Gridania (X:10.2, Y:9.4)",
                minimumLevel = 15,
                isActive = false
            ),
            SeasonalEvent(
                name = "Little Ladies' Day",
                description = "Festival celebrating women in FFXIV",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.MARCH, 3, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.MARCH, 17, 7, 59, 0)
                }.time,
                rewards = "Eastern-themed items and emotes",
                questStartLocation = "Ul'dah - Steps of Nald (X:9.6, Y:9.1)",
                minimumLevel = 15,
                isActive = false
            ),
            SeasonalEvent(
                name = "Hatching-tide",
                description = "FFXIV's Easter celebration",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.APRIL, 9, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.APRIL, 22, 7, 59, 0)
                }.time,
                rewards = "Egg and rabbit-themed items",
                questStartLocation = "Mih Khetto's Amphitheatre, Old Gridania (X:10.2, Y:9.4)",
                minimumLevel = 15,
                isActive = false
            ),
            SeasonalEvent(
                name = "The Make It Rain Campaign",
                description = "Gold Saucer event with increased MGP rewards",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.MAY, 15, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.MAY, 31, 7, 59, 0)
                }.time,
                rewards = "Gold Saucer items at discounted MGP prices",
                questStartLocation = "The Gold Saucer (X:5.1, Y:6.6)",
                minimumLevel = 15,
                isActive = false
            ),
            SeasonalEvent(
                name = "Moonfire Faire",
                description = "Summer beach festival in FFXIV",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.AUGUST, 8, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.AUGUST, 26, 7, 59, 0)
                }.time,
                rewards = "Summer and beach-themed items",
                questStartLocation = "Limsa Lominsa Upper Decks (X:11.5, Y:13.8)",
                minimumLevel = 30,
                isActive = false
            ),
            SeasonalEvent(
                name = "The Rising",
                description = "Anniversary celebration of FFXIV's rebirth",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.AUGUST, 27, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.SEPTEMBER, 11, 7, 59, 0)
                }.time,
                rewards = "Anniversary themed items and furnishings",
                questStartLocation = "Eastern La Noscea (X:30.1, Y:30.1)",
                minimumLevel = 15,
                isActive = false
            ),
            SeasonalEvent(
                name = "All Saints' Wake",
                description = "Halloween celebration in FFXIV",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.OCTOBER, 18, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.NOVEMBER, 4, 7, 59, 0)
                }.time,
                rewards = "Spooky and Halloween-themed items",
                questStartLocation = "Old Gridania (X:10.4, Y:8.4)",
                minimumLevel = 15,
                isActive = false
            ),
            SeasonalEvent(
                name = "Starlight Celebration",
                description = "Winter and Christmas celebration in FFXIV",
                startDate = Calendar.getInstance().apply {
                    set(2025, Calendar.DECEMBER, 15, 0, 0, 0)
                }.time,
                endDate = Calendar.getInstance().apply {
                    set(2025, Calendar.DECEMBER, 31, 7, 59, 0)
                }.time,
                rewards = "Winter and holiday-themed items and decorations",
                questStartLocation = "Old Gridania (X:10.2, Y:9.4)",
                minimumLevel = 15,
                isActive = false
            )
        )

        seasonalEventDao.insertEvents(events)
        updateActiveStatus()
    }
}