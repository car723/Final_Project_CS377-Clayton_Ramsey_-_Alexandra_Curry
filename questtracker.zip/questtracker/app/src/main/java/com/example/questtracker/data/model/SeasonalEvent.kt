package com.example.questtracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "seasonal_events")
data class SeasonalEvent(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val description: String,
    val startDate: Date,
    val endDate: Date,
    val rewards: String? = null,
    val questStartLocation: String? = null,
    val minimumLevel: Int,
    val isActive: Boolean = false,
    val imageUrl: String? = null
)