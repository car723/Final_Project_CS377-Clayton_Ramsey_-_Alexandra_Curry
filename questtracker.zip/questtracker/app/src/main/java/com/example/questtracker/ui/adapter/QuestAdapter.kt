package com.example.questtracker.ui.adapter

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.questtracker.R
import com.example.questtracker.data.model.Quest
import com.example.questtracker.databinding.ItemQuestBinding

class QuestAdapter(
    private val onQuestClicked: (Quest) -> Unit,
    private val onTrackClicked: (Quest) -> Unit
) : ListAdapter<Quest, QuestAdapter.QuestViewHolder>(QuestDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): QuestViewHolder {
        val binding = ItemQuestBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return QuestViewHolder(binding)
    }

    override fun onBindViewHolder(holder: QuestViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class QuestViewHolder(
        private val binding: ItemQuestBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        init {
            binding.root.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onQuestClicked(getItem(position))
                }
            }

            binding.btnTrackQuest.setOnClickListener {
                val position = adapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    onTrackClicked(getItem(position))
                }
            }
        }

        @SuppressLint("DefaultLocale", "SetTextI18n")
        fun bind(quest: Quest) {
            binding.apply {
                questTitle.text = quest.title
                questType.text = quest.questType.name.replace("_", " ")
                questLocation.text = quest.location
                questExpansion.text = quest.expansion.name.replace("_", " ")

                // Set time spent if available
                if (quest.timeSpentSeconds > 0) {
                    val hours = quest.timeSpentSeconds / 3600
                    val minutes = (quest.timeSpentSeconds % 3600) / 60
                    val seconds = quest.timeSpentSeconds % 60
                    questTimeSpent.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
                } else {
                    questTimeSpent.text = "00:00:00"
                }

                // Set completion status icon
                questStatus.setImageResource(
                    if (quest.isCompleted) R.drawable.ic_quest_complete
                    else R.drawable.ic_quest_incomplete
                )

                // Set icon based on quest type
                val iconResId = when (quest.questType) {
                    com.example.questtracker.data.model.QuestType.MAIN_SCENARIO -> R.drawable.ic_main_scenario
                    com.example.questtracker.data.model.QuestType.SEASONAL_EVENT -> R.drawable.ic_seasonal
                    // Add other quest types as needed
                    else -> R.drawable.ic_side_quest
                }
                questIcon.setImageResource(iconResId)
            }
        }
    }

    private class QuestDiffCallback : DiffUtil.ItemCallback<Quest>() {
        override fun areItemsTheSame(oldItem: Quest, newItem: Quest): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Quest, newItem: Quest): Boolean {
            return oldItem == newItem
        }
    }
}