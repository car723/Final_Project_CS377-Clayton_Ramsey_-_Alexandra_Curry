package com.example.questtracker.data.model

enum class FFXIVExpansion {
    A_REALM_REBORN,
    HEAVENSWARD,
    STORMBLOOD,
    SHADOWBRINGERS,
    ENDWALKER,
    DAWNTRAIL,
    UNKNOWN
}