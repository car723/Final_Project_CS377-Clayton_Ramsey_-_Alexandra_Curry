package com.example.questtracker.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.questtracker.data.model.SeasonalEvent
import com.example.questtracker.data.repository.SeasonalEventRepository
import com.example.questtracker.util.DateUtils
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@HiltViewModel
class SeasonalEventViewModel @Inject constructor(
    private val seasonalEventRepository: SeasonalEventRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    // All events
    val allEvents = seasonalEventRepository.getAllEvents()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Active events
    val activeEvents = seasonalEventRepository.getActiveEvents()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Upcoming events
    val upcomingEvents = seasonalEventRepository.getUpcomingEvents()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Filtered events based on search
    val filteredEvents = combine(
        _searchQuery,
        allEvents
    ) { query, events ->
        if (query.isEmpty()) {
            events
        } else {
            events.filter { event ->
                event.name.contains(query, ignoreCase = true) ||
                        event.description.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Flag to track if events have been loaded
    private val _hasLoadedEvents = MutableStateFlow(false)
    val hasLoadedEvents: StateFlow<Boolean> = _hasLoadedEvents.asStateFlow()

    init {
        // Safe initialization - don't call refreshEvents() directly
        viewModelScope.launch {
            try {
                // Update active status for all events
                seasonalEventRepository.updateActiveStatus()

                // Load initial data
                safelyFetchEvents()
            } catch (e: Exception) {
                // Log the error but don't crash
                Log.e("SeasonalEventViewModel", "Error initializing events: ${e.message}", e)
            }
        }
    }

    fun searchEvents(query: String) {
        _searchQuery.value = query
    }

    fun refreshEvents() {
        viewModelScope.launch {
            safelyFetchEvents()
        }
    }

    private suspend fun safelyFetchEvents() {
        try {
            // Update active status for all events
            seasonalEventRepository.updateActiveStatus()

            // Fetch events from API - run these independently so one failure doesn't stop others
            try {
                seasonalEventRepository.fetchAndSaveSeasonalEvents()
            } catch (e: Exception) {
                Log.e("SeasonalEventViewModel", "Error fetching seasonal events: ${e.message}", e)
            }

            try {
                seasonalEventRepository.fetchAndSaveActiveSeasonalEvents()
            } catch (e: Exception) {
                Log.e("SeasonalEventViewModel", "Error fetching active events: ${e.message}", e)
            }

            try {
                seasonalEventRepository.fetchAndSaveUpcomingSeasonalEvents()
            } catch (e: Exception) {
                Log.e("SeasonalEventViewModel", "Error fetching upcoming events: ${e.message}", e)
            }

            // Mark events as loaded even if some operations failed
            _hasLoadedEvents.value = true
        } catch (e: Exception) {
            // Log any other errors
            Log.e("SeasonalEventViewModel", "Error in fetchEvents: ${e.message}", e)
        }
    }

    fun getDaysRemaining(event: SeasonalEvent): Int {
        return DateUtils.daysUntil(event.endDate)
    }

    fun addEvent(event: SeasonalEvent) {
        viewModelScope.launch {
            seasonalEventRepository.insertEvent(event)
        }
    }

    fun updateEvent(event: SeasonalEvent) {
        viewModelScope.launch {
            seasonalEventRepository.updateEvent(event)
        }
    }

    fun deleteEvent(event: SeasonalEvent) {
        viewModelScope.launch {
            seasonalEventRepository.deleteEvent(event)
        }
    }

    fun getEventDetails(eventName: String) {
        viewModelScope.launch {
            seasonalEventRepository.fetchEventDetails(eventName)
        }
    }

    fun initializeWithDefaultEvents() {
        viewModelScope.launch {
            try {
                seasonalEventRepository.initializeWithDefaultEvents()
            } catch (e: Exception) {
                Log.e("SeasonalEventViewModel", "Error initializing default events: ${e.message}", e)
            }
        }
    }

    suspend fun getEventById(eventId: Long): SeasonalEvent? {
        return try {
            // First we need to get all events
            val allEvents = seasonalEventRepository.getAllEvents().first()
            // Then find the one with matching ID
            allEvents.find { it.id == eventId }
        } catch (e: Exception) {
            Log.e("SeasonalEventViewModel", "Error getting event by ID: ${e.message}", e)
            null
        }
    }

    // Utility functions for working with events
    fun getDaysUntilEvent(event: SeasonalEvent): Int {
        val currentDate = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.time

        val eventStartCal = Calendar.getInstance().apply {
            time = event.startDate
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val diff = eventStartCal.time.time - currentDate.time
        return (diff / (1000 * 60 * 60 * 24)).toInt()
    }

    fun getEventDuration(event: SeasonalEvent): Int {
        val startCal = Calendar.getInstance().apply {
            time = event.startDate
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val endCal = Calendar.getInstance().apply {
            time = event.endDate
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        val diff = endCal.time.time - startCal.time.time
        return (diff / (1000 * 60 * 60 * 24)).toInt() + 1 // +1 to include both start and end days
    }

    fun getEventStatus(event: SeasonalEvent): EventStatus {
        val currentDate = Date()

        return when {
            currentDate.before(event.startDate) -> EventStatus.UPCOMING
            currentDate.after(event.endDate) -> EventStatus.ENDED
            else -> EventStatus.ACTIVE
        }
    }

    enum class EventStatus {
        UPCOMING,
        ACTIVE,
        ENDED
    }
}