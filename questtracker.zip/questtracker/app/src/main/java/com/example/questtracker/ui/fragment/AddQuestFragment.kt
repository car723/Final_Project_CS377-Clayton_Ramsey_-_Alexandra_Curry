package com.example.questtracker.ui.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.questtracker.R
import com.example.questtracker.data.model.FFXIVExpansion
import com.example.questtracker.data.model.Quest
import com.example.questtracker.data.model.QuestType
import com.example.questtracker.databinding.FragmentAddQuestBinding
import com.example.questtracker.ui.viewmodel.QuestViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.Date

@AndroidEntryPoint
class AddQuestFragment : Fragment() {

    private var _binding: FragmentAddQuestBinding? = null
    private val binding get() = _binding!!

    private val questViewModel: QuestViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentAddQuestBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupSpinners()
        setupSeasonalEventVisibility()
        setupSubmitButton()
    }

    private fun setupSpinners() {
        // Setup Quest Type Spinner
        val questTypes = QuestType.entries.map { it.name.replace("_", " ") }
        val questTypeAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            questTypes
        )
        questTypeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerQuestType.adapter = questTypeAdapter

        // Setup Expansion Spinner
        val expansions = FFXIVExpansion.entries
            .filter { it != FFXIVExpansion.UNKNOWN }
            .map { it.name.replace("_", " ") }
        val expansionAdapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            expansions
        )
        expansionAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerExpansion.adapter = expansionAdapter

        // Set default values
        binding.spinnerQuestType.setSelection(questTypes.indexOf("SIDE QUEST"))
        binding.spinnerExpansion.setSelection(expansions.indexOf("DAWNTRAIL"))
    }

    private fun setupSeasonalEventVisibility() {
        binding.spinnerQuestType.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val selectedType = QuestType.entries[position]
                binding.seasonalEventFields.visibility = if (selectedType == QuestType.SEASONAL_EVENT) {
                    View.VISIBLE
                } else {
                    View.GONE
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
                // Do nothing
            }
        }
    }

    private fun setupSubmitButton() {
        binding.btnSubmit.setOnClickListener {
            if (validateInputs()) {
                saveQuest()
            }
        }
    }

    private fun validateInputs(): Boolean {
        var isValid = true

        // Validate Title
        if (binding.editTitle.text.isNullOrBlank()) {
            binding.editTitle.error = "Quest title is required"
            isValid = false
        }

        // Validate Description
        if (binding.editDescription.text.isNullOrBlank()) {
            binding.editDescription.error = "Quest description is required"
            isValid = false
        }

        // Validate Location
        if (binding.editLocation.text.isNullOrBlank()) {
            binding.editLocation.error = "Location is required"
            isValid = false
        }

        // Validate Quest Giver
        if (binding.editQuestGiver.text.isNullOrBlank()) {
            binding.editQuestGiver.error = "Quest giver is required"
            isValid = false
        }

        // Validate Required Level
        try {
            val level = binding.editRequiredLevel.text.toString().toIntOrNull()
            if (level == null || level < 1 || level > 100) {
                binding.editRequiredLevel.error = "Enter a valid level (1-100)"
                isValid = false
            }
        } catch (_: NumberFormatException) {
            binding.editRequiredLevel.error = "Enter a valid level"
            isValid = false
        }

        // Validate seasonal event name if it's a seasonal quest
        val selectedTypePosition = binding.spinnerQuestType.selectedItemPosition
        val selectedType = QuestType.entries[selectedTypePosition]
        if (selectedType == QuestType.SEASONAL_EVENT && binding.editSeasonalEventName.text.isNullOrBlank()) {
            binding.editSeasonalEventName.error = "Seasonal event name is required"
            isValid = false
        }

        return isValid
    }

    private fun saveQuest() {
        val title = binding.editTitle.text.toString()
        val description = binding.editDescription.text.toString()
        val location = binding.editLocation.text.toString()
        val questGiver = binding.editQuestGiver.text.toString()
        val requiredLevel = binding.editRequiredLevel.text.toString().toInt()

        val selectedTypePosition = binding.spinnerQuestType.selectedItemPosition
        val questType = QuestType.entries[selectedTypePosition]

        val selectedExpansionPosition = binding.spinnerExpansion.selectedItemPosition
        val expansion = FFXIVExpansion.entries
            .filter { it != FFXIVExpansion.UNKNOWN }[selectedExpansionPosition]

        // Seasonal event fields
        val isSeasonal = questType == QuestType.SEASONAL_EVENT
        val seasonalEventName = if (isSeasonal) {
            binding.editSeasonalEventName.text.toString()
        } else {
            null
        }

        // Create Quest object
        val quest = Quest(
            title = title,
            description = description,
            questType = questType,
            questGiver = questGiver,
            location = location,
            expansion = expansion,
            requiredLevel = requiredLevel,
            isCompleted = false,
            isSeasonal = isSeasonal,
            seasonalEventName = seasonalEventName,
            startDate = Date(),
            endDate = null,
            completedDate = null,
            timeSpentSeconds = 0L,
            lastActiveTimestamp = null,
            remoteId = null,
            rewards = binding.editRewards.text.toString(),
            unlocks = binding.editUnlocks.text.toString(),
            prerequisites = binding.editPrerequisites.text.toString()
        )

        // Save quest to database
        questViewModel.addQuest(quest)

        // Show success message and navigate back
        Toast.makeText(requireContext(), "Quest added successfully", Toast.LENGTH_SHORT).show()
        findNavController().navigateUp()
    }

    @Deprecated("Deprecated in Java")
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.menu_add_quest, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    @Deprecated("Deprecated in Java")
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_save -> {
                if (validateInputs()) {
                    saveQuest()
                }
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}