package com.example.questtracker.data.local

import androidx.room.*
import com.example.questtracker.data.model.FFXIVExpansion
import com.example.questtracker.data.model.Quest
import com.example.questtracker.data.model.QuestType
import kotlinx.coroutines.flow.Flow

@Dao
interface QuestDao {
    @Query("SELECT * FROM quests ORDER BY startDate DESC")
    fun getAllQuests(): Flow<List<Quest>>

    @Query("SELECT * FROM quests WHERE isSeasonal = 1 ORDER BY startDate DESC")
    fun getSeasonalQuests(): Flow<List<Quest>>

    @Query("SELECT * FROM quests WHERE questType = :questType ORDER BY startDate DESC")
    fun getQuestsByType(questType: QuestType): Flow<List<Quest>>

    @Query("SELECT * FROM quests WHERE expansion = :expansion ORDER BY startDate DESC")
    fun getQuestsByExpansion(expansion: FFXIVExpansion): Flow<List<Quest>>

    @Query("SELECT * FROM quests WHERE isCompleted = 0 ORDER BY startDate DESC")
    fun getActiveQuests(): Flow<List<Quest>>

    @Query("SELECT * FROM quests WHERE id = :questId")
    suspend fun getQuestById(questId: Long): Quest?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuest(quest: Quest): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuests(quests: List<Quest>)

    @Update
    suspend fun updateQuest(quest: Quest)

    @Delete
    suspend fun deleteQuest(quest: Quest)

    @Query("UPDATE quests SET timeSpentSeconds = timeSpentSeconds + :additionalSeconds WHERE id = :questId")
    suspend fun updateQuestTime(questId: Long, additionalSeconds: Long)

    @Query("UPDATE quests SET lastActiveTimestamp = :timestamp WHERE id = :questId")
    suspend fun updateLastActiveTimestamp(questId: Long, timestamp: Long)

    @Query("SELECT * FROM quests WHERE seasonalEventName = :eventName")
    fun getQuestsBySeasonalEvent(eventName: String): Flow<List<Quest>>

    @Query("SELECT * FROM quests WHERE title LIKE '%' || :search || '%' OR description LIKE '%' || :search || '%'")
    fun searchQuests(search: String): Flow<List<Quest>>
}