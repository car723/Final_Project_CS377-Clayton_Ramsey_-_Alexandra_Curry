package com.example.questtracker.ui.activity

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.example.questtracker.R
import com.example.questtracker.databinding.ActivityMainBinding
import com.example.questtracker.ui.viewmodel.QuestViewModel
import com.example.questtracker.ui.viewmodel.SeasonalEventViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var navController: NavController

    private val questViewModel: QuestViewModel by viewModels()
    private val seasonalEventViewModel: SeasonalEventViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Setup Navigation
        val navHostFragment = supportFragmentManager.findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        navController = navHostFragment.navController

        // Setup Bottom Navigation
        binding.bottomNav.setupWithNavController(navController)

        // Initialize data
        initializeData()
    }

    private fun initializeData() {
        // Initialize seasonal events if needed
        seasonalEventViewModel.initializeWithDefaultEvents()

        // Fetch quests from API
        questViewModel.fetchQuests()
    }
}