package com.example.questtracker.data.remote

import com.example.questtracker.data.model.CharacterResponse
import com.example.questtracker.data.model.CharacterSearchResponse
import com.example.questtracker.data.model.Quest
import com.example.questtracker.data.model.SeasonalEvent
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface FFXIVApi {
    @GET("character/search")
    suspend fun searchCharacter(
        @Query("name") name: String,
        @Query("server") server: String,
        @Query("private_key") apiKey: String? = null
    ): CharacterSearchResponse

    @GET("character/{id}")
    suspend fun getCharacter(
        @Path("id") id: Long,
        @Query("data") data: String = "AC", // A=Achievements, C=Character info
        @Query("extended") extended: Int = 1,
        @Query("private_key") apiKey: String? = null
    ): CharacterResponse

    @GET("quests")
    suspend fun getAllQuests(): List<Quest>

    @GET("seasonal-events")
    suspend fun getSeasonalEvents(): List<SeasonalEvent>

    @GET("seasonal-events/active")
    suspend fun getActiveSeasonalEvents(): List<SeasonalEvent>

    @GET("seasonal-events/upcoming")
    suspend fun getUpcomingSeasonalEvents(): List<SeasonalEvent>

    @GET("seasonal-events/{name}")
    suspend fun getEventDetails(@Path("name") eventName: String): SeasonalEvent

    @GET("track-quest-time/{id}")
    suspend fun trackQuestTime(
        @Path("id") questId: String,
        @Query("seconds") seconds: Long
    )
}