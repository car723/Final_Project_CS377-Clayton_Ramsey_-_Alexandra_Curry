package com.example.questtracker.ui.fragment

import android.annotation.SuppressLint
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.questtracker.R
import com.example.questtracker.data.model.CharacterSearchResult
import com.example.questtracker.data.model.FFXIVExpansion
import com.example.questtracker.databinding.FragmentCharacterBinding
import com.example.questtracker.ui.adapter.CharacterSearchAdapter
import com.example.questtracker.ui.adapter.ClassJobAdapter
import com.example.questtracker.ui.viewmodel.FFXIVCharacterViewModel
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.tabs.TabLayout
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import androidx.core.content.edit

@AndroidEntryPoint
class FFXIVCharacterFragment : Fragment() {

    private var _binding: FragmentCharacterBinding? = null
    private val binding get() = _binding!!

    private val viewModel: FFXIVCharacterViewModel by viewModels()
    private lateinit var searchAdapter: CharacterSearchAdapter
    private lateinit var classJobAdapter: ClassJobAdapter
    private lateinit var prefs: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PreferenceManager.getDefaultSharedPreferences(requireContext())
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCharacterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupServerSpinner()
        setupSearchRecyclerView()
        setupClassJobsRecyclerView()
        setupObservers()
        setupButtons()
        setupTabs()
        checkSavedCharacter()
    }

    private fun setupServerSpinner() {
        // FFXIV servers grouped by data center
        val servers = mapOf(
            "Aether" to listOf(
                "Adamantoise", "Cactuar", "Faerie", "Gilgamesh", "Jenova",
                "Midgardsormr", "Sargatanas", "Siren"
            ),
            "Crystal" to listOf(
                "Balmung", "Brynhildr", "Coeurl", "Diabolos", "Goblin",
                "Malboro", "Mateus", "Zalera"
            ),
            "Primal" to listOf(
                "Behemoth", "Excalibur", "Exodus", "Famfrit", "Hyperion",
                "Lamia", "Leviathan", "Ultros"
            ),
            "Chaos" to listOf(
                "Cerberus", "Louisoix", "Moogle", "Omega", "Phantom",
                "Ragnarok", "Sagittarius", "Spriggan"
            ),
            "Light" to listOf(
                "Alpha", "Lich", "Odin", "Phoenix", "Raiden",
                "Shiva", "Twintania", "Zodiark"
            ),
            "Elemental" to listOf(
                "Aegis", "Atomos", "Carbuncle", "Garuda", "Gungnir",
                "Kujata", "Tonberry", "Typhon"
            ),
            "Gaia" to listOf(
                "Alexander", "Bahamut", "Durandal", "Fenrir", "Ifrit",
                "Ridill", "Tiamat", "Ultima"
            ),
            "Mana" to listOf(
                "Anima", "Asura", "Chocobo", "Hades", "Ixion",
                "Masamune", "Pandaemonium", "Titan"
            ),
            "Meteor" to listOf(
                "Belias", "Mandragora", "Ramuh", "Shinryu", "Unicorn",
                "Valefor", "Yojimbo", "Zeromus"
            ),
            "Dynamis" to listOf(
                "Halicarnassus", "Maduin", "Marilith", "Seraph", "Sephirot"
            ),
            "Materia" to listOf(
                "Bismarck", "Ravana", "Siren", "Sophia", "Zurvan"
            )
        )

        // Create a flattened list
        val allServers = servers.values.flatten().sorted()

        val adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            allServers
        )
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerServer.adapter = adapter

        // Set default server if saved
        val savedServer = prefs.getString("last_server", null)
        if (!savedServer.isNullOrEmpty()) {
            val position = allServers.indexOf(savedServer)
            if (position >= 0) {
                binding.spinnerServer.setSelection(position)
            }
        }
    }

    private fun setupSearchRecyclerView() {
        searchAdapter = CharacterSearchAdapter { character ->
            // Handle character selection
            loadCharacterDetails(character)
        }

        binding.recyclerSearchResults.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = searchAdapter
        }
    }

    private fun setupClassJobsRecyclerView() {
        classJobAdapter = ClassJobAdapter(
            onTrackProgress = { classJob ->
                // Handle tracking class/job leveling progress
                showTrackProgressDialog(classJob)
            }
        )

        binding.recyclerClassJobs.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = classJobAdapter
        }
    }

    @SuppressLint("SetTextI18n")
    private fun setupObservers() {
        // Search results
        viewModel.searchResults.observe(viewLifecycleOwner) { results ->
            searchAdapter.submitList(results)

            // Show/hide empty view
            binding.searchResultsContainer.visibility = if (results.isEmpty()) View.GONE else View.VISIBLE
            binding.emptyResultsView.visibility = if (results.isEmpty() && !binding.progressBar.isShown) View.VISIBLE else View.GONE
        }

        // Character details
        viewModel.characterData.observe(viewLifecycleOwner) { character ->
            if (character != null) {
                // Show character info section and setup character info
                binding.characterInfoCard.visibility = View.VISIBLE
                binding.characterName.text = character.name
                binding.characterServer.text = character.server
                binding.characterLevel.text = "Level ${character.activeClassJob?.level ?: "?"}"
                binding.characterActiveJob.text = character.activeClassJob?.name ?: "Unknown"

                // Save character to preferences for next time
                prefs.edit {
                    putLong("last_character_id", character.id)
                        .putString("last_character_name", character.name)
                        .putString("last_server", character.server)
                }

                // Update class jobs list
                classJobAdapter.submitList(character.classJobs ?: emptyList())

                // Load MSQ progress
                viewModel.loadCompletedMSQs(character.id)
            } else {
                binding.characterInfoCard.visibility = View.GONE
            }
        }

        // MSQ completion
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.completedMSQs.collectLatest { msqMap ->
                if (msqMap.isNotEmpty()) {
                    binding.msqProgressGroup.visibility = View.VISIBLE

                    // Update MSQ progress indicators
                    updateMSQProgress(msqMap)

                    // Enable import button if at least one MSQ is completed
                    binding.btnImportQuests.isEnabled = msqMap.values.any { it }
                } else {
                    binding.msqProgressGroup.visibility = View.GONE
                }
            }
        }

        // Active quests
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.activeQuests.collectLatest { quests ->
                // Update active quests section
                binding.activeQuestsContainer.visibility = if (quests.isEmpty()) View.GONE else View.VISIBLE
                binding.emptyQuestsView.visibility = if (quests.isEmpty() && binding.characterInfoCard.isShown) View.VISIBLE else View.GONE

                // Update the active quests list
                // In a real implementation, you would have an adapter set up
            }
        }

        // Loading state
        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE

            // Hide empty views when loading
            if (isLoading) {
                binding.emptyResultsView.visibility = View.GONE
                binding.emptyQuestsView.visibility = View.GONE
            }
        }

        // Error state
        viewModel.error.observe(viewLifecycleOwner) { error ->
            error?.let {
                Snackbar.make(binding.root, it, Snackbar.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupButtons() {
        // Search button
        binding.btnSearch.setOnClickListener {
            val characterName = binding.editCharacterName.text.toString().trim()
            val server = binding.spinnerServer.selectedItem.toString()

            if (characterName.isBlank()) {
                binding.editCharacterName.error = "Character name is required"
                return@setOnClickListener
            }

            // Perform search
            viewModel.searchCharacter(characterName, server)

            // Save the server for next time
            prefs.edit().putString("last_server", server).apply()
        }

        // Import quests button
        binding.btnImportQuests.setOnClickListener {
            viewModel.importCompletedMSQsAsQuests()
            Snackbar.make(binding.root, "MSQ progress imported as quests", Snackbar.LENGTH_SHORT).show()

            // Navigate back to quest list
            findNavController().navigate(R.id.action_FFXIVCharacterFragment_to_questListFragment)
        }

        // Sync all quests button
        binding.btnSyncAllQuests.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Sync All Quests")
                .setMessage("This will attempt to sync all your in-game quests to the app. Are you sure you want to continue?")
                .setPositiveButton("Sync") { _, _ ->
                    viewModel.syncAllQuests()
                    Snackbar.make(binding.root, "Syncing quests from your character...", Snackbar.LENGTH_LONG).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun setupTabs() {
        binding.contentTabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                when (tab.position) {
                    0 -> { // Jobs tab
                        binding.jobsContainer.visibility = View.VISIBLE
                        binding.questsContainer.visibility = View.GONE
                        binding.achievementsContainer.visibility = View.GONE
                    }
                    1 -> { // Quests tab
                        binding.jobsContainer.visibility = View.GONE
                        binding.questsContainer.visibility = View.VISIBLE
                        binding.achievementsContainer.visibility = View.GONE

                        // Load active quests if needed
                        if (viewModel.currentCharacterId > 0) {
                            viewModel.loadActiveQuests()
                        }
                    }
                    2 -> { // Achievements tab
                        binding.jobsContainer.visibility = View.GONE
                        binding.questsContainer.visibility = View.GONE
                        binding.achievementsContainer.visibility = View.VISIBLE

                        // Load achievements if needed
                        if (viewModel.currentCharacterId > 0) {
                            viewModel.loadAchievements(viewModel.currentCharacterId)
                        }
                    }
                }
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }

    private fun checkSavedCharacter() {
        // Check if we have a previously loaded character
        val characterId = prefs.getLong("last_character_id", -1)
        val characterName = prefs.getString("last_character_name", null)

        if (characterId != -1L && !characterName.isNullOrEmpty()) {
            // Show saved character info
            binding.savedCharacterInfo.visibility = View.VISIBLE
            binding.savedCharacterName.text = characterName

            // Setup load saved character button
            binding.btnLoadSavedCharacter.setOnClickListener {
                viewModel.loadCharacter(characterId)
            }
        } else {
            binding.savedCharacterInfo.visibility = View.GONE
        }
    }

    private fun loadCharacterDetails(character: CharacterSearchResult) {
        viewModel.loadCharacter(character.id)
    }

    @SuppressLint("SetTextI18n")
    private fun updateMSQProgress(msqMap: Map<String, Boolean>) {
        // Update MSQ progress indicators
        updateMSQIndicator(binding.indicatorArr, msqMap["A Realm Reborn"] ?: false)
        updateMSQIndicator(binding.indicatorHw, msqMap["Heavensward"] ?: false)
        updateMSQIndicator(binding.indicatorSb, msqMap["Stormblood"] ?: false)
        updateMSQIndicator(binding.indicatorShb, msqMap["Shadowbringers"] ?: false)
        updateMSQIndicator(binding.indicatorEw, msqMap["Endwalker"] ?: false)
        updateMSQIndicator(binding.indicatorDt, msqMap["Dawntrail"] ?: false)

        // Calculate overall MSQ progress percentage
        val completedExpansions = msqMap.values.count { it }
        val totalExpansions = msqMap.size
        val progressPercentage = (completedExpansions * 100) / totalExpansions

        binding.msqProgressBar.progress = progressPercentage
        binding.msqProgressText.text = "$progressPercentage% Complete"
    }

    private fun updateMSQIndicator(indicator: View, completed: Boolean) {
        val color = if (completed) {
            ContextCompat.getColor(requireContext(), R.color.quest_complete)
        } else {
            ContextCompat.getColor(requireContext(), R.color.quest_incomplete)
        }

        indicator.setBackgroundColor(color)
    }

    private fun showTrackProgressDialog(classJob: Any) {
        // This is a placeholder for tracking class/job leveling progress
        // In a real implementation, you'd show a dialog to track leveling progress
        Snackbar.make(binding.root, "Tracking progress for leveling: $classJob", Snackbar.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}