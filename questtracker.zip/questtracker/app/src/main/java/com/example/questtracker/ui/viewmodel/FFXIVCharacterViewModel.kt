package com.example.questtracker.ui.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.questtracker.data.model.Achievement
import com.example.questtracker.data.model.CharacterData
import com.example.questtracker.data.model.CharacterSearchResult
import com.example.questtracker.data.model.FFXIVExpansion
import com.example.questtracker.data.model.Quest
import com.example.questtracker.data.model.QuestType
import com.example.questtracker.data.repository.FFXIVRepository
import com.example.questtracker.data.repository.QuestRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import java.util.Date
import javax.inject.Inject

@HiltViewModel
class FFXIVCharacterViewModel @Inject constructor(
    private val ffxivRepository: FFXIVRepository,
    private val questRepository: QuestRepository
) : ViewModel() {

    // Character search
    private val _searchResults = MutableLiveData<List<CharacterSearchResult>>()
    val searchResults: LiveData<List<CharacterSearchResult>> = _searchResults

    // Character details
    private val _characterData = MutableLiveData<CharacterData?>()
    val characterData: LiveData<CharacterData?> = _characterData

    // Character achievements
    private val _achievements = MutableLiveData<List<Achievement>>()
    val achievements: LiveData<List<Achievement>> = _achievements

    // Completed MSQs
    private val _completedMSQs = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val completedMSQs: StateFlow<Map<String, Boolean>> = _completedMSQs

    // Active quests for the character
    private val _activeQuests = MutableStateFlow<List<Quest>>(emptyList())
    val activeQuests: StateFlow<List<Quest>> = _activeQuests

    // Loading states
    private val _isLoading = MutableLiveData<Boolean>(false)
    val isLoading: LiveData<Boolean> = _isLoading

    // Error state
    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error

    // Lodestone ID for the current character
    private var _currentCharacterId: Long = -1
    val currentCharacterId: Long get() = _currentCharacterId

    fun searchCharacter(name: String, server: String) {
        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            ffxivRepository.searchCharacter(name, server)
                .catch { e ->
                    _error.value = "Error searching for character: ${e.message}"
                    _isLoading.value = false
                }
                .collect { result ->
                    result.fold(
                        onSuccess = { characters ->
                            _searchResults.value = characters
                            _isLoading.value = false
                        },
                        onFailure = { e ->
                            _error.value = "Error searching for character: ${e.message}"
                            _isLoading.value = false
                        }
                    )
                }
        }
    }

    fun loadCharacter(id: Long) {
        _isLoading.value = true
        _error.value = null
        _currentCharacterId = id

        viewModelScope.launch {
            ffxivRepository.getCharacterDetails(id)
                .catch { e ->
                    _error.value = "Error loading character: ${e.message}"
                    _isLoading.value = false
                }
                .collect { result ->
                    result.fold(
                        onSuccess = { character ->
                            _characterData.value = character
                            _isLoading.value = false

                            // Once character is loaded, automatically load MSQ progress
                            loadCompletedMSQs(id)
                        },
                        onFailure = { e ->
                            _error.value = "Error loading character: ${e.message}"
                            _isLoading.value = false
                        }
                    )
                }
        }
    }

    fun loadAchievements(id: Long) {
        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            ffxivRepository.getCharacterAchievements(id)
                .catch { e ->
                    _error.value = "Error loading achievements: ${e.message}"
                    _isLoading.value = false
                }
                .collect { result ->
                    result.fold(
                        onSuccess = { achievementList ->
                            _achievements.value = achievementList
                            _isLoading.value = false
                        },
                        onFailure = { e ->
                            _error.value = "Error loading achievements: ${e.message}"
                            _isLoading.value = false
                        }
                    )
                }
        }
    }

    fun loadCompletedMSQs(id: Long) {
        _isLoading.value = true
        _error.value = null

        viewModelScope.launch {
            ffxivRepository.getCompletedMSQs(id)
                .catch { e ->
                    _error.value = "Error loading MSQ progress: ${e.message}"
                    _isLoading.value = false
                }
                .collect { result ->
                    result.fold(
                        onSuccess = { msqMap ->
                            _completedMSQs.value = msqMap
                            _isLoading.value = false
                        },
                        onFailure = { e ->
                            _error.value = "Error loading MSQ progress: ${e.message}"
                            _isLoading.value = false
                        }
                    )
                }
        }
    }

    fun loadActiveQuests() {
        viewModelScope.launch {
            try {
                val quests = questRepository.getActiveQuests().firstOrNull() ?: emptyList()
                _activeQuests.value = quests
            } catch (e: Exception) {
                _error.value = "Error loading active quests: ${e.message}"
            }
        }
    }

    fun importCompletedMSQsAsQuests() {
        viewModelScope.launch {
            val msqMap = _completedMSQs.value
            val character = _characterData.value ?: return@launch

            if (msqMap.isEmpty()) {
                _error.value = "No MSQ data available"
                return@launch
            }

            // Create quests for each completed MSQ
            msqMap.forEach { (expansion, isCompleted) ->
                if (isCompleted) {
                    val ffxivExpansion = when (expansion) {
                        "A Realm Reborn" -> FFXIVExpansion.A_REALM_REBORN
                        "Heavensward" -> FFXIVExpansion.HEAVENSWARD
                        "Stormblood" -> FFXIVExpansion.STORMBLOOD
                        "Shadowbringers" -> FFXIVExpansion.SHADOWBRINGERS
                        "Endwalker" -> FFXIVExpansion.ENDWALKER
                        "Dawntrail" -> FFXIVExpansion.DAWNTRAIL
                        else -> FFXIVExpansion.UNKNOWN
                    }

                    val quest = Quest(
                        title = "$expansion MSQ Complete",
                        description = "Main Scenario Quests for $expansion completed by ${character.name} on ${character.server}",
                        questType = QuestType.MAIN_SCENARIO,
                        questGiver = "FFXIV",
                        location = "Eorzea",
                        expansion = ffxivExpansion,
                        requiredLevel = 90, // Default max level
                        isCompleted = true,
                        isSeasonal = false,
                        startDate = Date(),
                        completedDate = Date(),
                        remoteId = "${character.id}-$expansion"
                    )

                    questRepository.insertQuest(quest)
                }
            }
        }
    }

    fun syncAllQuests() {
        viewModelScope.launch {
            // This would ideally implement a complex sync mechanism
            // For now, we'll just import the MSQ data we have
            importCompletedMSQsAsQuests()
        }
    }

    fun refreshCharacterData() {
        if (_currentCharacterId <= 0) return

        _isLoading.value = true
        viewModelScope.launch {
            ffxivRepository.refreshCharacterData(_currentCharacterId)
                .collect { result ->
                    result.fold(
                        onSuccess = { character ->
                            _characterData.value = character
                            _isLoading.value = false
                            // Also refresh MSQ progress data
                            loadCompletedMSQs(_currentCharacterId)
                        },
                        onFailure = { error ->
                            _error.value = "Failed to refresh data: ${error.message}"
                            _isLoading.value = false
                        }
                    )
                }
        }
    }
}