import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const FFXIVQuestDashboard = ({ questData: propsQuestData = [] }) => {
  const [questData, setQuestData] = useState(propsQuestData);
  const [expansionData, setExpansionData] = useState([]);
  const [typeData, setTypeData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Color schemes based on your FFXIV theme colors
  const EXPANSION_COLORS = ['#3B5998', '#D4AF37', '#8B0000', '#682531', '#796D30', '#80A0BC'];
  const TYPE_COLORS = ['#A8D2E6', '#9C0A10', '#682531', '#796D30', '#488C34', '#627A1E', '#7A5CBF', '#936844'];

  useEffect(() => {
      if (propsQuestData && propsQuestData.length > 0) {
        setQuestData(propsQuestData);

        // Process expansion data
        const expCounts = {};
        propsQuestData.forEach(quest => {
          const exp = quest.expansion || 'Unknown';
          expCounts[exp] = (expCounts[exp] || 0) + 1;
        });

        const expData = Object.keys(expCounts).map(key => ({
          name: key.replace(/_/g, ' '),
          value: expCounts[key]
        }));

        // Process quest type data
        const typeCounts = {};
        propsQuestData.forEach(quest => {
          const type = quest.questType || 'Unknown';
          typeCounts[type] = (typeCounts[type] || 0) + 1;
        });

        const tData = Object.keys(typeCounts).map(key => ({
          name: key.replace(/_/g, ' '),
          value: typeCounts[key]
        }));

        setExpansionData(expData);
        setTypeData(tData);
        setIsLoading(false);
      }
    }, [propsQuestData]);

  // Calculate completion statistics
  const totalQuests = questData.length;
  const completedQuests = questData.filter(q => q.isCompleted === 'true').length;
  const completionRate = totalQuests > 0 ? Math.round((completedQuests / totalQuests) * 100) : 0;

  if (isLoading) {
    return (
      <div className="flex h-64 w-full items-center justify-center">
        <div className="text-center">
          <div className="text-xl font-bold text-gray-700">Loading Quest Data...</div>
          <div className="mt-4 text-gray-500">Please wait while we fetch your quest information</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-center mb-6 text-gray-800">FFXIV Quest Tracker Dashboard</h2>

      {/* Statistics cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <div className="text-4xl font-bold text-blue-700">{totalQuests}</div>
          <div className="text-sm text-blue-600">Total Quests</div>
        </div>

        <div className="bg-green-50 p-4 rounded-lg border border-green-200">
          <div className="text-4xl font-bold text-green-700">{completedQuests}</div>
          <div className="text-sm text-green-600">Completed Quests</div>
        </div>

        <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
          <div className="text-4xl font-bold text-purple-700">{completionRate}%</div>
          <div className="text-sm text-purple-600">Completion Rate</div>
        </div>
      </div>

      {/* Charts section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Expansion distribution chart */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-4 text-gray-700">Quests by Expansion</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={expansionData}
                cx="50%"
                cy="50%"
                labelLine={false}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {expansionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={EXPANSION_COLORS[index % EXPANSION_COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Quest type distribution chart */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <h3 className="text-lg font-semibold mb-4 text-gray-700">Quests by Type</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart
              data={typeData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" name="Number of Quests">
                {typeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={TYPE_COLORS[index % TYPE_COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent activity section */}
      <div className="mt-8">
        <h3 className="text-lg font-semibold mb-4 text-gray-700">Recent Quest Activity</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full bg-white">
            <thead className="bg-gray-100">
              <tr>
                <th className="py-2 px-4 text-left text-sm font-medium text-gray-600">Quest Title</th>
                <th className="py-2 px-4 text-left text-sm font-medium text-gray-600">Type</th>
                <th className="py-2 px-4 text-left text-sm font-medium text-gray-600">Expansion</th>
                <th className="py-2 px-4 text-left text-sm font-medium text-gray-600">Status</th>
                <th className="py-2 px-4 text-left text-sm font-medium text-gray-600">Time Spent</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {questData.slice(0, 5).map((quest, index) => (
                <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                  <td className="py-2 px-4 text-sm text-gray-900">{quest.title}</td>
                  <td className="py-2 px-4 text-sm text-gray-500">{quest.questType?.replace(/_/g, ' ') || 'Unknown'}</td>
                  <td className="py-2 px-4 text-sm text-gray-500">{quest.expansion?.replace(/_/g, ' ') || 'Unknown'}</td>
                  <td className="py-2 px-4 text-sm">
                    <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full ${quest.isCompleted === 'true' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`}>
                      {quest.isCompleted === 'true' ? 'Completed' : 'In Progress'}
                    </span>
                  </td>
                  <td className="py-2 px-4 text-sm text-gray-500">
                    {formatTime(parseInt(quest.timeSpentSeconds || '0'))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Helper function to format time
const formatTime = (seconds) => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

export default FFXIVQuestDashboard;